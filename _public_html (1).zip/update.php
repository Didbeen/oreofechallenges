<?php
include 'forms/formule.php';
if (isset($_GET['id']) && isset($_GET['type'])) {
    $produit_id = $_GET['id'];
    $produit_type = $_GET['type'];

    // Récupérer les informations du produit à modifier depuis la base de données
    // Utilisez $produit_id pour sélectionner le bon enregistrement.
    // Vous devrez probablement avoir des tables séparées pour les voitures et les appartements
    // ou une table unique avec une colonne 'type' pour les différencier.
    // Exemple (à adapter à votre structure de base de données) :
    if ($produit_type === 'voiture') {
        $voiture = mysqli_query($link, "SELECT * FROM cars WHERE idc = $produit_id");
    } elseif ($produit_type === 'appartement') {
        $appartement = mysqli_query($link, "SELECT * FROM biens WHERE idt = $produit_id");
    } else {
        echo "Type de produit invalide.";
        exit;
    }
} else {
    echo "ID ou type de produit manquant.";
    exit;
}

if (isset($_POST['voiture'])) {
    var_dump($_POST);
$mark = $_POST['marque'];
$mod = $_POST['model'];
$an = $_POST['an'];
$carb = $_POST['carbur'];
$des = $_POST['desc'];

$ok = mysqli_query($link, "UPDATE cars SET `marque` = '$mark', `modele` = '$mod', `annee` = '$an', `desc` = '$des'  WHERE `idc` = $produit_id");
if ($ok) {
    $requ = 1;
            $_SESSION['message'] = "Modification effectuée ! ...";
    header('Location: parametre.php?requ='.$requ); exit();
    }
}

if (isset($_POST['appartement'])) {
    $typ = $_POST['type'];
    $name = $_POST['nom'];
    $np = $_POST['np'];
    $nc = $_POST['nc'];
    $vil = $_POST['vil'];
    $adr = $_POST['adresse'];
    $libe = $_POST['libel'];

    $ok = mysqli_query($link, "UPDATE biens SET nom = '$name' , libel = '$libe', `type` = '$typ' , `npiece` = '$np', nchambre = '$nc', adresse = '$adr', ville = '$vil'  WHERE idt = $produit_id");
    if ($ok) {
            $requ = 1;
                    $_SESSION['message'] = "Modification effectuée ! ...";
            header('Location: parametre.php?requ='.$requ); exit();
            }
    }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Oreofe Challenges - Location de voitures</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">


    <!-- Favicons -->
    <link href="img/occ.png" rel="icon">
    <link href="img/occ.png" rel="apple-touch-icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,400;0,700;0,900;1,400;1,700;1,900&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <style>
        .form-voiture {
            display: none;
        }

        .form-appartement {
            display: none;
        }
        .image-preview {
            max-width: 200px;
            height: auto;
            margin-bottom: 10px;
            border: 1px solid #ccc;
        }
    </style>
</head>

<body>

    <!-- Spinner Start -->
    <!-- <div id="spinner"
        class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only"></span>
        </div>
    </div> -->
    <!-- Spinner End -->


    <!-- Navbar & Hero Start -->
    <div class="container-fluid nav-bar sticky-top px-0 px-lg-4 py-lg-0">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a href="index.php" class="navbar-brand p-1">
                    <img src="img/oc.png" alt="Logo">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="fa fa-bars"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav mx-auto py-0">
                        <a href="index.php" class="nav-item nav-link ">Accueil</a>
                        <a href="about.php" class="nav-item nav-link">A propos</a>
                        <a href="cars.php" class="nav-item nav-link"> Nos véhicules</a>
                        <a href="properties.php" class="nav-item nav-link">Nos hébergements</a>
                        <a href="parametre.php" class="nav-item nav-link active">Paramètres</a>
                        <!-- <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                                <div class="dropdown-menu m-0">
                                    <a href="feature.html" class="dropdown-item">Fonctionalités</a>
                                    <a href="cars.html" class="dropdown-item">Voitures</a>
                                    <a href="team.html" class="dropdown-item">Notre équipe</a>
                                    <a href="testimonial.html" class="dropdown-item">Témoignages</a>
                                    <a href="404.html" class="dropdown-item">404 Page</a>
                                </div>
                            </div> -->
                        <a href="contact.php" class="nav-item nav-link">Contact</a>
                    </div>
                </div>
                <a href="immobilier.html" class="display-7 text-secondary "><i class="fas fa-home me-3"></i><b>Besoin
                        d'hébergement ?</b></i></a>
            </nav>
        </div>
    </div>
    <!-- Navbar & Hero End -->

    <!-- Header Start -->
    <div class="container-fluid bg-breadcrumb">
        <div class="container text-center py-5" style="max-width: 900px;">
            <h4 class="text-white display-4 mb-4 wow fadeInDown" data-wow-delay="0.1s">Paramètres</h4>
            <ol class="breadcrumb d-flex justify-content-center mb-0 wow fadeInDown" data-wow-delay="0.3s">
                <li class="breadcrumb-item"><a href="index.html">Accueil</a></li>
                <li class="breadcrumb-item"><a href="#">Pages</a></li>
                <li class="breadcrumb-item active text-primary">Paramètres</li>
            </ol>
        </div>
    </div>
    <!-- Header End -->

    <!-- Banner Start -->
    <div class="container-fluid banner p-5 wow zoomInDown" data-wow-delay="0.1s">
        <div class="container pb-5">
            <div class="banner-item rounded">
                <img src="img/banner-1.jpg" class="img-fluid rounded w-100" alt="">
                <div class="banner-content">
                    <?php if ($produit_type === 'voiture' && isset($voiture)): 
                    while ($voitures = mysqli_fetch_array($voiture, MYSQLI_ASSOC)) { ?>
                    <form action="" method="POST" enctype="multipart/form-data" id="form-voiture" class="sign-up-form"
                        data-aos="fade-up" data-aos-delay="300">             
                        <h4 class="text-white mb-4"> MODIFIER UNE VOITURE ! </h4>
                        <div class="row g-3">                        
                            <div class="col-12">
                                <div class="input-group">
                                    <input class="form-control" name="marque" id="marque" type="text"
                                        value="<?= $voitures['marque'] ?>" aria-label="" required>
                                    <input class="form-control ms-3" name="an" id="an" type="number"
                                        value="<?= $voitures['annee'] ?>" aria-label="" required>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="input-group">
                                    <input class="form-control" name="model" id="model" type="text" 
                                        value="<?= $voitures['modele'] ?>" aria-label=""> 
                                    <select class="form-select ms-3" name="carbur" id="carbur">
                                        <option  value="<?= $voitures['carbur'] ?>" ><?= $voitures['carbur'] ?></option>
                                        <option value="Essence">Essence</option>
                                        <option value="Diesel">Diesel</option>
                                        <option value="Electrique">Electrique</option>
                                        <option value="Hybride">Hybride</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="input-group">
                                    <input class="form-control" name="desc" id="desc" type="text"
                                        value="<?= $voitures['desc'] ?>" aria-label="">
                                </div>
                            </div>
                            <div class="col-12 mb-4">
                                <img src="assets/car/<?= $voitures['img'] ?>" alt="Première photo" class="image-preview">
                                <img src="assets/car/<?= $voitures['img1'] ?>" alt="Deuxième photo" class="image-preview">
                                <img src="assets/car/<?= $voitures['img2'] ?>" alt="Troisième photo" class="image-preview">
                            </div>
                        </div>
                        <div class="col-12">
                            <button type="submit" name="voiture"
                                class="btn btn-light w-100 py-2">Enrégistrer</button>
                        </div>
                    </form>
                    <?php } endif; ?>

                    <?php if ($produit_type === 'appartement' && isset($appartement)): 
                    while ($appartements = mysqli_fetch_array($appartement, MYSQLI_ASSOC)) { ?>

                    <form action="" method="POST" enctype="multipart/form-data" id="form-appartement"
                        class="sign-up-form " data-aos="fade-up" data-aos-delay="300">
                        <h4 class="text-white mb-4"> MODIFIER UN HEBERGEMENT ! </h4>
                        <div class="row g-3">
                            <div class="col-12">
                                <div class="input-group">
                                    <select class="form-select" name="type" id="type">
                                        <option value="<?= $appartements['type'] ?>" ><?= $appartements['type'] ?></option>
                                        <option value="appartement">Appartement</option>
                                        <option value="maison">Maison</option>
                                        <option value="terrain">Parcelle</option>
                                        <option value="menage">Ménage</option>
                                    </select>
                                    <input class="form-control ms-3" name="nom" id="nom" type="text"
                                        value="<?= $appartements['nom'] ?>" aria-label="" required>
                                </div>

                            </div>
                            <div class="col-12">
                                <div class="input-group">
                                    <input class="form-control" name="vil" id="vil" type="text"
                                        value="<?= $appartements['ville'] ?>" aria-label="" required>
                                    <input class="form-control ms-3" name="adresse" id="adresse" type="text"
                                        value="<?= $appartements['adresse'] ?>" aria-label="" required>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="input-group">
                                    <input class="form-control" name="libel" id="libel" type="text" 
                                        value="<?= $appartements['libel'] ?>" aria-label="" required>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="input-group">
                                    <input class="form-control" name="np" id="np" type="number"
                                        value="<?= $appartements['npiece'] ?>" aria-label="" required>
                                    <input class="form-control ms-3" name="nc" id="nc" type="number"
                                        value="<?= $appartements['nchambre'] ?>" aria-label="" required>
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <img src="assets/images/<?= $appartements['imgp'] ?>" alt="Première image" class="image-preview">
                                <img src="assets/images/<?= $appartements['imgs'] ?>" alt="Deuxième image" class="image-preview">
                                <img src="assets/images/<?= $appartements['img1'] ?>" alt="Troisième image" class="image-preview">
                                <img src="assets/images/<?= $appartements['img2'] ?>" alt="Dernière image" class="image-preview">
                            </div>
                        </div>
                        <div class="col-12">
                            <button type="submit" name="appartement"
                                class="btn btn-light w-100 py-2">Enrégistrer</button>
                        </div>
                    </form>
                    <?php } endif; ?>
                </div>
            </div>
        </div>
    </div>


        <!-- Footer Start -->
        <div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-md-6 col-lg-6 col-xl-3">
                        <div class="footer-item d-flex flex-column">
                            <div class="footer-item">
                                <h4 class="text-white mb-4">A propos</h4>
                                <p class="mb-3">Besoin d’une <b>voiture</b> ou d’un <b>appartement</b> ? Contactez-nous
                                    dès
                                    maintenant pour réserver ou obtenir plus d’informations</p>
                            </div>
                            <div class="position-relative">
                                <input class="form-control rounded-pill w-100 py-3 ps-4 pe-5" type="text"
                                    placeholder="Enter your email">
                                <button type="button"
                                    class="btn btn-secondary rounded-pill position-absolute top-0 end-0 py-2 mt-2 me-2">Abonnez
                                    - vous !</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 col-xl-3">
                        <div class="footer-item d-flex flex-column">
                            <h4 class="text-white mb-4">Liens rapides</h4>
                            <a href="about.php"><i class="fas fa-angle-right me-2"></i> A propos</a>
                            <a href="cars.php"><i class="fas fa-angle-right me-2"></i> Nos voitures</a>
                            <a href="properties.php"><i class="fas fa-angle-right me-2"></i>Nos propriétés</a>
                            <a href="contact.php"><i class="fas fa-angle-right me-2"></i> Contactez - nous !</a>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 col-xl-5">
                        <div class="footer-item d-flex flex-column">
                            <h4 class="text-white mb-4"> Nos Contacts</h4>
                            <a href="#"><i class="fa fa-map-marker-alt me-2"></i> BP 1517, CENSAD Erevan, Cotonou,
                                Bénin</a>
                            <a href="mailto:oreofechallenges@gmail.com"><i class="fas fa-envelope me-2"></i>
                                oreofechallenges@gmail.com</a>
                            <a href="tel:+012 345 67890"><i class="fas fa-phone me-2"></i> +229 01 943 716 16</a>
                            <a href="tel:+012 345 67890" class="mb-3"><i class="fas fa-print me-2"></i> +229 01 974 474
                                77</a>
                        </div>
                    </div>
                    <div class="col-md-3 col-lg-3 col-xl-1">
                        <div class="footer-item d-flex flex-column">
                            <div class="mb-3">
                                <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                    href="https://m.facebook.com/people/Or%25C3%25A9of%25C3%25AA-Challenges/100088868176677"><i
                                        class="fab fa-facebook-f text-white"></i></a>
                            </div>
                            <div class="mb-3">
                                <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                    href="https://www.tiktok.com/%40orofchallenges"><i
                                        class="fab fa-tiktok text-white"></i></a>
                            </div>
                            <div class="mb-3">
                                <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                    href="https://www.instagram.com/oreofe_challenges/"><i
                                        class="fab fa-instagram text-white"></i></a>
                            </div>
                            <div class="mb-3">
                                <a class="btn btn-secondary btn-md-square rounded-circle me-0"
                                    href="https://bj.linkedin.com/company/oreofe-challenges"><i
                                        class="fab fa-linkedin-in text-white"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->

        <!-- Copyright Start -->
        <div class="container-fluid copyright py-4">
            <div class="container">
                <div class="row g-4 align-items-center">
                    <div class="col-md-8 text-center text-md-start mb-md-0">
                        <span class="text-body"><a href="#" class="border-bottom text-white"><i
                                    class="fas fa-copyright text-light me-2"></i>OREOFE CHALLENGES LOCATION DE VOITURES
                                ET
                                HEBERGEMENTS</a>, All right reservés.</span>
                    </div>
                    <div class="col-md-4 text-center text-md-end text-body">
                        <!--/*** This template is free as long as you keep the below author’s credit link/attribution link/backlink. ***/-->
                        <!--/*** If you'd like to use the template without the below author’s credit link/attribution link/backlink, ***/-->
                        <!--/*** you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". ***/-->
                        Designed By <a class="border-bottom text-white" href="mailto:digitalnative3@gmail.com"> Digital
                            Native</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Copyright End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-secondary btn-lg-square rounded-circle back-to-top"><i
                class="fa fa-arrow-up"></i></a>


        <!-- JavaScript Libraries -->
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const formVoiture = document.getElementById('formVoiture');
                const formAppartement = document.getElementById('formAppartement');
                const produitType = "<?php echo $produit_type; ?>";

                if (produitType === 'voiture') {
                    formVoiture.style.display = 'block';
                    formAppartement.style.display = 'none';
                } else if (produitType === 'appartement') {
                    formAppartement.style.display = 'block';
                    formVoiture.style.display = 'none';
                }
            });
        </script>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="lib/wow/wow.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/counterup/counterup.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>


        <!-- Template Javascript -->
        <script src="js/main.js"></script>
</body>

</html>