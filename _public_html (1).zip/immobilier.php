<?php
include 'forms/formule.php';

  $bien = mysqli_query($link, "SELECT * FROM biens");
  // $comment = mysqli_query($link, "SELECT * FROM comment");
?>
<!DOCTYPE html>
<html lang="fr">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
    rel="stylesheet">

  <title>OREOFE CHALLENGES - IMMOBILIER</title>

  <link href="img/occ.png" rel="icon">
  <link href="img/occ.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


  <!-- Additional CSS Files -->
  <link rel="stylesheet" href="assets/css/fontawesome.css">
  <link rel="stylesheet" href="assets/css/templatemo-villa-agency.css">
  <link rel="stylesheet" href="assets/css/owl.css">
  <link rel="stylesheet" href="assets/css/animate.css">
  <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />
  <!--

TemplateMo 591 villa agency

https://templatemo.com/tm-591-villa-agency

-->
</head>

<body>

  <!-- ***** Preloader Start ***** -->
  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
      </div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->

  <!--<div class="sub-header">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-8">
          <ul class="info">
            <li><i class="fa fa-envelope"></i> info@company.com</li>
            <li><i class="fa fa-map"></i> Sunny Isles Beach, FL 33160</li>
          </ul>
        </div>
        <div class="col-lg-4 col-md-4">
          <ul class="social-links">
            <li><a href="#"><i class="fab fa-facebook"></i></a></li>
            <li><a href="https://x.com/minthu" target="_blank"><i class="fab fa-twitter"></i></a></li>
            <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>

   ***** Header Area Start ***** -->
  <header class="header-area header-sticky">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav">
            <!-- ***** Logo Start ***** -->
            <a href="index.php" class="logo p-3">
              <img src="img/oc.png" alt="OREOFE CHALLENGES" style="width: 200px; height: auto;" class="img-fluid">
            </a>
            <!-- ***** Logo End ***** -->
            <!-- ***** Menu Start ***** -->
            <ul class="nav">
              <li><a href="index.php" class="active">Accueil</a></li>
              <li><a href="about.php">A propos</a></li>
              <li><a href="properties.php">Nos hébergements</a></li>
              <li><a href="contact.php">Contacts</a></li>
              <li><a href="properties.php"><i class="fa fa-calendar"></i> Demander une visite</a></li>
            </ul>
            <a class='menu-trigger'>
              <span>Menu</span>
            </a>
            <!-- ***** Menu End ***** -->
          </nav>
        </div>
      </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->

  <div class="main-banner">
    <div class="owl-carousel owl-banner " data-bs-interval="5000">
      <div class="item item-1 ">
        <div class="header-text">
          <span class="category">Cotonou, <em>Bénin</em></span>
          <h2>Votre hébergement,<br> Notre priorité</h2>
        </div>
      </div>
      <div class="item item-2">
        <div class="header-text">
          <span class="category">Haie Vive, <em>Bénin</em></span>
          <h2>Chez vous !<br> Comme nulle part </h2>
        </div>
      </div>
      <div class="item item-3">
        <div class="header-text">
          <span class="category">Calavi, <em>Bénin</em></span>
          <h2>Possedez <br>un appartement de luxe </h2>
        </div>
      </div>
    </div>
  </div>

  <div class="featured section">
    <div class="container">
      <div class="row">
        <div class="col-lg-4">
          <div class="left-image">
            <img src="assets/images/feature.jpg" alt="">
            <a href="property-details.html"><img src="assets/images/featured-icon.png" alt=""
                style="max-width: 60px; padding: 0px;"></a>
          </div>
        </div>
        <div class="col-lg-8">
          <div class="section-heading pb-5">
            <h6>| Actualités </h6>
            <h3> Nous disposons de Meilleurs Appartments </h3>
          </div>
          <div class="accordion" id="accordionExample">
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingOne">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne"
                  aria-expanded="true" aria-controls="collapseOne">
                  <b>Qui sommes - nous ?</b>
                </button>
              </h2>
              <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne"
                data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  Chez <strong><a href="index.html" target="_blank">OREOFE
                                            CHALLENGES</a></strong> nous croyons en la responsabilité sociale.
                                    En plus de fournir des services de classe mondiale, nous nous engageons à donner en
                                    retour
                                    aux communautés que nous desservons. Nos initiatives sociales visent à créer un
                                    impact positif,
                                    de la réduction de notre <b>empreinte carbone</b> à la contribution à des causes
                                    sociales.<a href="contact.php">Contactez-nous</a> pour organiser une visite</div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingTwo">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                  <b>Comment ça marche ?</b>
                </button>
              </h2>
              <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  Gràce à notre <strong>plateforme disponnible en ligne</strong>, vous trouverez rapidement le bien qui
                  correspond à vos besoins.
                  Nous sommes à l'écoute de vos <code>projets</code> et nous nous adaptons à vos envies
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingThree">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                  <b>Pourquoi sommes - nous les meileurs ?</b>
                </button>
              </h2>
              <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree"
                data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  Que vous soyez à la recherche d'une <strong>résidence principal</strong>,d'un <b>investissement
                    locatif</b> ou bien d'un bien de <b>prestige</b>
                  , nous mettons notre <code>expertise</code> à votre service. Bénéficiez de notre
                  <code>connaissance approfondie du marché local</code> et de notre <code>réseau interenational</code>
                  pour réaliser tout vos <b>projets immobiliers</b>.
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- <div class="col-lg-3">
          <div class="info-table">
            <ul>
              <li>
                <img src="assets/images/info-icon-01.png" alt="" style="max-width: 52px;">
                <h4>250 m2<br><span>Surface Totale </span></h4>
              </li>
              <li>
                <img src="assets/images/info-icon-02.png" alt="" style="max-width: 52px;">
                <h4>Contract<br><span>Contract à jour</span></h4>
              </li>
              <li>
                <img src="assets/images/info-icon-03.png" alt="" style="max-width: 52px;">
                <h4>Paiement<br><span>Moyen de Paiement</span></h4>
              </li>
              <li>
                <img src="assets/images/info-icon-04.png" alt="" style="max-width: 52px;">
                <h4>Sécurité<br><span>24/7 Sous Controle</span></h4>
              </li>
            </ul>
          </div>
        </div> -->
      </div>
    </div>
  </div>

  <div class="video section">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 offset-lg-2">
          <div class="section-heading text-center">
            <a href="">
              <h6>| Video de Propriétés </h6>
              <h2>Prenez une vue de plus près ! </h2>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="video-content">
    <div class="container">
      <div class="row">
        <div class="col-lg-10 offset-lg-1">
          <div class="video-frame">
            <img src="assets/images/video-frame.jpg" alt="">
            <a href="properties.php" target="_blank"><i class="fa fa-play"></i></a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="fun-facts">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="wrapper">
            <div class="row">
              <div class="col-lg-4">
                <div class="counter">
                  <h2 class="timer count-title count-number" data-to="34" data-speed="1000"></h2>
                  <p class="count-text ">Proprités<br>louées</p>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="counter">
                  <h2 class="timer count-title count-number" data-to="3" data-speed="1000"></h2>
                  <p class="count-text ">Années<br>d'Experience</p>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="counter">
                  <h2 class="timer count-title count-number" data-to="55" data-speed="1000"></h2>
                  <p class="count-text ">Clients<br>Satisfaits</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="section best-deal">
    <div class="container">
      <div class="row">
        <div class="col-lg-4">
          <div class="section-heading">
            <h6>| Hébergements de luxe</h6>
            <h3>Découvrez votre meilleur hébergement !</h3>
          </div>
        </div>
        <div class="col-lg-12">
          <div class="tabs-content">
            <div class="row">
              <div class="nav-wrapper ">
                <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="appartment-tab" data-bs-toggle="tab"
                      data-bs-target="#appartment" type="button" role="tab" aria-controls="appartment"
                      aria-selected="true">Appartements</button>
                  </li>
                  <li class="nav-item" role="presentation">
                    <button class="nav-link" id="villa-tab" data-bs-toggle="tab" data-bs-target="#villa" type="button"
                      role="tab" aria-controls="villa" aria-selected="false">Maison Villa</button>
                  </li>
                  <li class="nav-item" role="presentation">
                    <button class="nav-link" id="penthouse-tab" data-bs-toggle="tab" data-bs-target="#penthouse"
                      type="button" role="tab" aria-controls="penthouse" aria-selected="false">Immeuble</button>
                  </li>
                </ul>
              </div>
              <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="appartment" role="tabpanel" aria-labelledby="appartment-tab">
                  <div class="row">
                    <div class="col-lg-3">
                      <div class="info-table">
                        <ul>
                          <li>Surface Totale <span>185 m2</span></li>
                          <li>Numero d'étage <span>2 </span></li>
                          <li>Nombre de chambres <span>4</span></li>
                          <li>Garage <span>Disponible</span></li>
                          <li>Moyen de Paiement <span>Tout</span></li>
                        </ul>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <img src="assets/images/deal 1.jpg" alt="">
                    </div>
                    <div class="col-lg-3">
                      <h4>Infos sur la Propriété</h4>
                      <p><b>Adresse</b> : Fidjrossè, Cotonou
                        <br><b>Description</b> : Premier étage, entrée personnelle avec accès engin. Salle
                        de bain Douche séparée de la cuisine Véranda avec baie vitrée Climatisation installée Couloir
                        spacieux
                        <!-- <br><b>Commodités</b> : Compteur electrique personnel
                        <br><b>Loyer mensuel</b> 70.000 FCFA
                        <br><b>Conditions</b> : 3 mois Commission, 1 mois Caution (EE) : 50.000 FCFA. -->
                      </p>
                      <div class="icon-button">
                        <a href="property-details.html"><i class="fa fa-calendar"></i> Demander une visite</a>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="tab-pane fade" id="villa" role="tabpanel" aria-labelledby="villa-tab">
                  <div class="row">
                    <div class="col-lg-3">
                      <div class="info-table">
                        <ul>
                          <li>Surface Totale <span>250 m2</span></li>
                          <li>Numero d'étage <span>0</span></li>
                          <li>Nombre de chambres <span>5</span></li>
                          <li>Garage <span>Disponible</span></li>
                          <li>Moyen de paiement <span>Banque</span></li>
                        </ul>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <img src="assets/images/deal 2.jpg" alt="">
                    </div>
                    <div class="col-lg-3">
                      <h4>Infos sur la Propriété</h4>
                      <p><b>Adresse</b> :Abomey Calavi
                        <br><b>Description</b> : Chambres climatisées, sanitaires, Salon staffé, avec un
                        couloir spacieux, Arrière-cour, Placards dans toutes les pièces.
                        <!-- <br><b>Commodités</b> : Compteur électrique personnel.
                        <br><b>Loyer mensuel</b>: 120.000 FCFA.
                        <br><b>Conditions</b> : 3 mois de caution + 1 mois d’avance + 1 mois pour l’agence + 50.000 FCFA
                        de caution peinture. -->
                      </p>
                      <div class="icon-button">
                        <a href="property-details.html"><i class="fa fa-calendar"></i> Demander une visite</a>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="tab-pane fade" id="penthouse" role="tabpanel" aria-labelledby="penthouse-tab">
                  <div class="row">
                    <div class="col-lg-3">
                      <div class="info-table">
                        <ul>
                          <li>Surface Totale <span>320 m2</span></li>
                          <li>Numero d'étage <span>4</span></li>
                          <li>Nombre de chambres<span>6</span></li>
                          <li>Garage<span>Disponible</span></li>
                          <li>Moyen de paiement <span>Tout</span></li>
                        </ul>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <img src="assets/images/deal 3.jpg" alt="">
                    </div>
                    <div class="col-lg-3">
                      <h4>Infos sur la Propriété </h4>
                      <p><b>Adresse</b> :Calavi Ahossougbéta, près du Carrefour La Rossette. Nouvelle construction dans
                        un quartier calme et accessible.
                        <br><b>Description</b> : Chambres & salon staffé, Cuisine séparée avec arrière-cour.
                        <!-- <br><b>Commodités</b> : Compteur électrique personnel à carte, Eau par forage, 5 Ménages -->
                        <!-- <br><b>Loyer mensuel</b> : 85.000 FCFA
                        <br><b>Conditions</b> : 3 mois d’avance + 2 mois prépayés, Caution peinture : 80.000 FCFA
                        Commission d’immobilier : 85.000 FCFA -->
                      </p>
                      <div class="icon-button">
                        <a href="property-details.html"><i class="fa fa-calendar"></i>Demander une visite</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="properties section">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 offset-lg-2">
          <div class="section-heading text-center">
            <h6>| Nos propriétés</h6>
            <h2>Nous proposons les meilleures propriétés que vous aimez ! </h2>
          </div>
        </div>
      </div>
      <div class="row">
        <?php while ($biens = mysqli_fetch_array($bien, MYSQLI_ASSOC)) { ?>
        <div class="col-lg-4 col-md-6">
          <div class="item">
            <a href="property-details.php?code=<?= $biens['idt'] ?>">
              <img src="img/<?= $biens['imgp'] ?>" style="max-height: 320px;"alt="<?= $biens['nom'] ?>">
            </a>
            <span class="category text-capitalize">
              <?= $biens['type'] ?>
            </span>
            <h4><a href="property-details.php?code=<?= $biens['idt'] ?>">
                <?= $biens['ville'] ?>
              </a></h4>
            <ul>
              <li>Pièces: <span>
                  <?= $biens['npiece'] ?>
                </span></li>
              <li>Chambres: <span>
                  <?= $biens['nchambre'] ?>
                </span></li>
              <!-- <li>Superficie: <span>
                  <?= $biens['superficie'] ?> m²
                </span></li> -->
                
            </ul>
            <div class="main-button">
              <a href="property-details.php?code=<?= $biens['idt'] ?>">Demander une visite</a>
            </div>
          </div>
        </div>
        <?php } ?>
      </div>
    </div>
  </div>

  <div class="contact section">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 offset-lg-4">
          <div class="section-heading text-center">
          <a href="contact.php"></a>  
            <h6>| Contactez - Nous</h6>
            <h2>Contactez - Nous dès maintenant</h2>
          </a>
          </div>
        </div>
      </div>
    </div>
  </div>


   <!-- Footer Start -->
    <div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <div class="footer-item">
                            <h4 class="text-white mb-4">A propos</h4>
                            <p class="mb-3">Besoin d’une <b>voiture</b> ou d’un <b>appartement</b> ? Contactez-nous dès
                                maintenant pour réserver ou obtenir plus d’informations</p>
                        </div>
                        <div class="position-relative">
                            <input class="form-control rounded-pill w-100 py-3 ps-4 pe-5" type="text"
                                placeholder="Enter your email">
                            <button type="button"
                                class="btn btn-secondary rounded-pill position-absolute top-0 end-0 py-2 mt-2 me-2">Abonnez
                                - vous !</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-white mb-4">Liens rapides</h4>
                        <a href="about.php"><i class="fas fa-angle-right me-2"></i> A propos</a>
                        <a href="cars.php"><i class="fas fa-angle-right me-2"></i> Nos voitures</a>
                        <a href="properties.php"><i class="fas fa-angle-right me-2"></i>Nos propriétés</a>
                        <a href="contact.php"><i class="fas fa-angle-right me-2"></i> Contactez - nous !</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-5">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-white mb-4"> Nos Contacts</h4>
                        <a href="#"><i class="fa fa-map-marker-alt me-2"></i> BP 1517, CENSAD Erevan, Cotonou, Bénin</a>
                        <a href="mailto:oreofechallenges@gmail.com"><i class="fas fa-envelope me-2"></i>
                            oreofechallenges@gmail.com</a>
                        <a href="tel:+012 345 67890"><i class="fas fa-phone me-2"></i> +229 01 943 716 16</a>
                        <a href="tel:+012 345 67890" class="mb-3"><i class="fas fa-print me-2"></i> +229 01 974 474
                            77</a>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-xl-1">
                    <div class="footer-item d-flex flex-column">
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                href="https://m.facebook.com/people/Or%25C3%25A9of%25C3%25AA-Challenges/100088868176677"><i
                                    class="fab fa-facebook-f text-white"></i></a>
                        </div>
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                href="https://www.tiktok.com/%40orofchallenges"><i
                                    class="fab fa-tiktok text-white"></i></a>
                        </div>
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                href="https://www.instagram.com/oreofe_challenges/"><i
                                    class="fab fa-instagram text-white"></i></a>
                        </div>
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-0"
                                href="https://bj.linkedin.com/company/oreofe-challenges"><i
                                    class="fab fa-linkedin-in text-white"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->

    <!-- Copyright Start -->
    <div class="container-fluid copyright py-4">
        <div class="container">
            <div class="row g-4 align-items-center">
                <div class="col-md-8 text-center text-md-start mb-md-0">
                    <span class="text-body"><a href="#" class="border-bottom text-white"><i
                                class="fas fa-copyright text-light me-2"></i>OREOFE CHALLENGES LOCATION DE VOITURES ET
                            HEBERGEMENTS</a>, All right reservés.</span>
                </div>
                <div class="col-md-4 text-center text-md-end text-body">
                    <!--/*** This template is free as long as you keep the below author’s credit link/attribution link/backlink. ***/-->
                    <!--/*** If you'd like to use the template without the below author’s credit link/attribution link/backlink, ***/-->
                    <!--/*** you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". ***/-->
                    Designed By <a class="border-bottom text-white" href="mailto:digitalnative3@gmail.com"> Digital
                        Native</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Copyright End -->


  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/js/isotope.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/counter.js"></script>
  <script src="assets/js/custom.js"></script>

</body>

</html>