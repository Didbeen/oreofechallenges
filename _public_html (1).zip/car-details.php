<?php
include 'forms/formule.php';
  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\SMTP;
  use PHPMailer\PHPMailer\Exception;

  require 'PHPMailer/phpmailer/phpmailer/src/Exception.php';
  require 'PHPMailer/phpmailer/phpmailer/src/PHPMailer.php';
  require 'PHPMailer/phpmailer/phpmailer/src/SMTP.php';

  $code = $_GET['code']; 
if ($code == "") {
    header('Location: 404.html');
} else {
  $car = mysqli_query($link, "SELECT * FROM cars where idc=$code");
  $row = mysqli_fetch_array($car, MYSQLI_ASSOC);
  $model = $row['modele'];
  $voiture = mysqli_query($link, "SELECT * FROM cars where modele like '%$model%'");

}

  if(isset($_POST['reserver'])){
    $nom = $_POST['nom']; $mark = $row['marque'];
    $depart = ($_POST['depart'] != null) ? $_POST['depart'] : "Non renseigné";
    $retour = ($_POST['retour'] != null) ? $_POST['retour'] : "Non renseigné";
    $jdep = ($_POST['jdep'] != null) ? $_POST['jdep'] : "Non renseigné";
    $hdep = ($_POST['hdep'] != null) ? $_POST['hdep'] : "Non renseigné";
    $jret = ($_POST['jret'] != null) ? $_POST['jret'] : "Non renseigné";
    $hret = ($_POST['hret'] != null) ? $_POST['hret'] : "Non renseigné";
    $email = $_POST['mail'];
    $tel = ($_POST['tel'] != null) ? $_POST['tel'] : "Non renseigné";
  //Create an instance; passing `true` enables exceptions
  $mail = new PHPMailer(true);
  
  try {
      //Server settings
        $mail->SMTPDebug = 0;
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'oreofechallenges@gmail.com';                     //SMTP username
        $mail->Password   = 'apdrdfvpheydykjb';                               //SMTP password
        $mail->SMTPSecure = 'ssl';            //Enable implicit TLS encryption ENCRYPTION_STARTTLS
        $mail->Port       = 465;                                  //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

      //Recipients
        $mail->setFrom($email, $nom);
        $mail->addAddress('oreofechallenges@gmail.com','<b>Réservation de véhicule<b> | Site OREOFE CHALLENGES');  
      //  $mail->addAddress($_POST['email'], $_POST['name']);     //Add a recipient
      // $mail->addAddress('ellen@example.com');               //Name is optional
        $mail->addReplyTo($email, $nom);
        //Content
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Réservation du véhicule :'.$mark;
        $mail->Body    = '<strong> Numero de téléphone :<strong> '.$tel.'
                            <br><strong> E - Mail :<strong> '.$email.'
                            <br><strong>Message : <strong> Mr/Mme '.$nom.' réserve le véhicule '.$mark.' à l\'adresse '.$depart.' 
                                le '.$jdep.' à '.$hdep.' heures vers l\'adresse '.$retour.' le '.$jret.' à '.$hret;
        $mail->AltBody = '<strong>Réservation de véhicule demandée de Mr/Mme '.$nom.'<strong>';
        $mail->send();
        echo "<script>window.alert('Réservation Envoyée! Vous serez recontacté d\'ici peu !')</script>";
  } catch (Exception $e) {
      echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}"; 
  }
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Cental - Car Rent Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,400;0,700;0,900;1,400;1,700;1,900&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    <!-- Spinner Start -->
    <div id="spinner"
        class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->


    <!-- Navbar & Hero Start -->
    <div class="container-fluid nav-bar sticky-top px-0 px-lg-4 py-lg-0">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a href="" class="navbar-brand p-1">
                    <img src="img/oc.png" alt="Logo">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="fa fa-bars"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav mx-auto py-0">
                        <a href="index.php" class="nav-item nav-link ">Accueil</a>
                        <a href="about.php" class="nav-item nav-link">A propos</a>
                        <a href="cars.php" class="nav-item nav-link active"> Nos véhicules</a>
                        <a href="properties.php" class="nav-item nav-link">Nos hébergements</a>

                        <!-- <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                            <div class="dropdown-menu m-0">
                                <a href="feature.html" class="dropdown-item">Fonctionalités</a>
                                <a href="cars.html" class="dropdown-item">Voitures</a>
                                <a href="team.html" class="dropdown-item">Notre équipe</a>
                                <a href="testimonial.html" class="dropdown-item">Témoignages</a>
                                <a href="404.html" class="dropdown-item">404 Page</a>
                            </div>
                        </div> -->
                        <a href="contact.php" class="nav-item nav-link">Contact</a>
                    </div>
                </div>
                <a href="immobilier.php" class="display-7 text-secondary "><i class="fas fa-home me-3"></i><b>Besoin
                        d'hébergement ?</b></i></a>
            </nav>
        </div>
    </div>
    <!-- Navbar & Hero End -->

    <!-- Navbar & Hero End -->

    <!-- Header Start -->
    <div class="container-fluid bg-breadcrumb">
        <div class="container text-center py-5" style="max-width: 900px;">
            <h4 class="text-white display-4 mb-4 wow fadeInDown" data-wow-delay="0.1s">
                <?= $row['modele'] ?>
            </h4>
            <ol class="breadcrumb d-flex justify-content-center mb-0 wow fadeInDown" data-wow-delay="0.3s">
                <li class="breadcrumb-item"><a href="index.html">Accueil</a></li>
                <li class="breadcrumb-item"><a href="cars.html">Page</a></li>
                <li class="breadcrumb-item active text-primary">Details du véhicule</li>
            </ol>
        </div>
    </div>
    <!-- Header End -->

    <div class="container-fluid service py-5 ">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-8">
                    <div id="carouselId" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000">
                        <ol class="carousel-indicators">
                            <li data-bs-target="#carouselId" data-bs-slide-to="0" class="active" aria-current="true"
                                aria-label="First slide"></li>
                            <li data-bs-target="#carouselId" data-bs-slide-to="1" aria-label="Second slide"></li>
                            <li data-bs-target="#carouselId" data-bs-slide-to="2" aria-label="Third slide"></li>
                        </ol>
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active">
                                <img src="assets/car/<?= $row['img'] ?>" style="max-height: 500px;" class="img-fluid "
                                    alt="First slide" />
                            </div>
                            <div class="carousel-item">
                                <img src="assets/car/<?= $row['img1'] ?>" style="max-height: 500px;" class="img-fluid "
                                    alt="Second slide" />
                            </div>
                            <div class="carousel-item">
                                <img src="assets/car/<?= $row['img2'] ?>" style="max-height: 500px;" class="img-fluid "
                                    alt="Third slide" />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="bg-white rounded">
                        <table class="table  table-striped text-align-justify" id="table">
                            <tr class="bg-hover">
                                <td class="fw-bold"><i class="fa fa-car"></i> Marque : </td>
                                <td class="fw-bold">
                                    <?= $row['marque'] ?>
                                </td>
                            </tr>
                            <tr class="bg-hover">
                                <td class="fw-bold"><i class="fa fa-gas-pump"></i> Carburant : </td>
                                <td class="fw-bold">
                                    <?= $row['carbur'] ?>
                                </td>
                            </tr>
                            <tr class="bg-hover">
                                <td class="fw-bold"><i class="fa fa-cogs"></i> Année de conception : </td>
                                <td class="fw-bold">
                                    <?= $row['annee'] ?>
                                </td>
                            </tr>
                            <tr class="bg-hover">
                                <td class="fw-bold"><i class="fa fa-car-alt"></i> Description : </td>
                                <td class="fw-bold">
                                    <?= $row['desc'] ?>
                                </td>
                            </tr>
                            <?php if ($row['etat'] == 1) {
                                echo '<tr class="bg-hover">
                                <td class="fw-bold text-center" colspan="2">
                                    <button type="button" id="reserver"
                                        class="btn btn-secondary rounded-pill py-3 px-4 px-md-5 me-2 "><i
                                            class="fa fa-car"></i> Réservation</button>
                                </td>
                            </tr>';
                            } else {
                                echo '<tr class="bg-hover">
                                <td class="fw-bold text-center" colspan="2">
                                    Ce véhicule est actuellement indisponible. 
                                    Revenez une autre fois pour la réservation.
                                    <a href="tel:+2290194371616">Contactez - nous</a> pour en savoir plus.
                                </td>
                            </tr>';
                            }?>
                        </table>
                        <!-- Modal -->
                        <div class="modal-content w-100 bg-light" id="mreserver" style="display: none;">
                            <div class="modal-header text-center bg-primary">
                                <h5 class="modal-title" id="exampleModalLabel4">Réservation du véhicule :
                                    <?= $row['modele'] ?>
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body p-4">
                                <form action="" method="POST" role="form" class="sign-up-form ">
                                    <!-- Name input -->
                                    <div class="row g-3">
                                        <div class="col-12">
                                            <input class="form-control col-lg-6" id="marque" name="marque" type="text"
                                                placeholder="<?= $row['marque'] ?> " value="<?= $row['marque'] ?>"
                                                disabled>
                                            <input class="form-control col-lg-6 mt-3" type="text" name="nom" id="nom"
                                                placeholder="Entrer votre nom et prénoms" required>
                                        </div>
                                        <div class="col-12">
                                            <div class="input-group">
                                                <div
                                                    class="d-flex align-items-center bg-light text-body rounded-start p-auto">
                                                    <span class="fas fa-map-marker-alt"></span><span class="ms-1">Lieu
                                                        de départ
                                                    </span>
                                                </div>
                                                <input class="form-control" name="depart" id="depart" type="text"
                                                    placeholder="Entrer une adresse"
                                                    aria-label="Enter a City or Airport" required>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <a href="#" class="text-start text-red d-block mb-2">Besoin d'une
                                                Destination ?</a>
                                            <div class="input-group">
                                                <div
                                                    class="d-flex align-items-center bg-light text-body rounded-start p-auto">
                                                    <span class="fas fa-map-marker-alt"></span><span
                                                        class="ms-1">Destination</span>
                                                </div>
                                                <input class="form-control" name="retour" id="retour" type="text"
                                                    placeholder="Entrer une adresse"
                                                    aria-label="Enter a City or Airport" required>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="input-group">
                                                <div
                                                    class="d-flex align-items-center bg-light text-body rounded-start p-auto">
                                                    <span class="fas fa-calendar-alt"></span><span
                                                        class="ms-1">Depart</span>
                                                </div>
                                                <input class="form-control" name="jdep" id="jdep" type="date" required>
                                                <input class="form-control ms-3" type="time" name="hdep" id="hdep"
                                                    required>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="input-group">
                                                <div
                                                    class="d-flex align-items-center bg-light text-body rounded-start p-auto">
                                                    <span class="fas fa-calendar-alt"></span><span
                                                        class="ms-1">Arrivée</span>
                                                </div>
                                                <input class="form-control" name="jret" id="jret" type="date" required>
                                                <input class="form-control ms-3" type="time" name="hret" id="ret">
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="input-group">
                                                <div class="col-lg-6">
                                                    <input class="form-control" type="email" name="mail" id="mail"
                                                        pattern="[^ @]*@[^ @]*" placeholder="Votre E-mail..." required>
                                                </div>
                                                <div class="col-lg-6">
                                                    <input class="form-control ms-3" type="phone" name="tel" id="tel"
                                                        placeholder="Entrer votre numéro de téléphone" required>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Submit button -->
                                        <button type="submit" name="reserver" id="reserver"
                                            class="btn btn-secondary rounded-pill py-3 px-4 px-md-5 me-2">Réserver</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- Modal End -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('reserver').addEventListener('click', function () {
            document.getElementById('mreserver').style.display = 'block';
            document.getElementById('table').style.display = 'none';
        });
    </script>

    <!-- Blog Start -->
    <div class="container-fluid blog py-5">
        <div class="container py-5">
            <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 800px;">
                <h1 class="display-5 text-capitalize mb-3">Trouvez des<span class="text-primary"> véhicules</span>
                    semblables</h1>
                <p class="mb-0">Explorez notre flotte exclusive de voitures haut de gamme. Des modèles de prestige, un
                    entretien rigoureux et des options de personnalisation vous garantissent une expérience de conduite
                    incomparable.
                </p>
            </div>
            <div class="row g-4">
                <?php while ($voitures = mysqli_fetch_array($voiture, MYSQLI_ASSOC)) { ?>
                <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="blog-item">
                        <div class="blog-img">
                            <img src="assets/car/<?= $voitures['img'] ?>" class="img-fluid rounded-top w-100"
                                alt="Image">
                        </div>
                        <div class="blog-content rounded-bottom p-4">
                            <div class="blog-date">
                                <?= $voitures['marque'] ?>
                            </div>
                            <div class="blog-comment my-3">
                                <div class="small"><span class="fa fa-user text-primary"></span><span class="ms-2">
                                        <?= $voitures['modele'] ?>
                                    </span></div>
                                <div class="small"><span class="fa fa-comment-alt text-primary"></span><span
                                        class="ms-2">
                                        <?= $voitures['annee'] ?>
                                    </span></div>
                            </div>
                            <a href="https://wa.me/0194371616?text=Je%20veux%20un%20Chauffeur%20professionnel"
                                class="h4 d-block mb-3">Besoin d'un chauffeur prrofessionnel ?</a>
                            <p class="mb-3">
                                <?= $voitures['desc'] ?>
                            </p>
                            <a href="car-details.php?code=<?= $voitures['idc'] ?>" class="">Lire plus<i    class="fa fa-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <!-- Blog End -->

    <!-- Banner Start -->
    <div class="container-fluid banner pb-5 wow zoomInDown" data-wow-delay="0.1s">
        <div class="container pb-5">
            <div class="banner-item rounded">
                <img src="img/banner-1.jpg" class="img-fluid rounded w-100" alt="">
                <div class="banner-content">
                    <h2 class="text-primary">Louez Votre Voiture </h2>
                    <h2 class="text-white">Interressé par la <b>Location</b> ?</h2>
                    <h5 class="text-white">N'hesitez pas, envoyez - nous un message.</h5>
                    <div class="banner-btn">
                        <a href="https://wa.me/0194371616"
                            class="btn btn-secondary rounded-pill py-3 px-4 px-md-4 me-2">WhatsApp</a>
                        <a href="contact.php" class="btn btn-primary rounded-pill py-3 px-4 px-md-4 ms-2">Contactez -
                            Nous!</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Banner End -->


    <!-- Footer Start -->
    <div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <div class="footer-item">
                            <h4 class="text-white mb-4">A propos</h4>
                            <p class="mb-3">Besoin d’une <b>voiture</b> ou d’un <b>appartement</b> ? Contactez-nous dès
                                maintenant pour réserver ou obtenir plus d’informations</p>
                        </div>
                        <div class="position-relative">
                            <input class="form-control rounded-pill w-100 py-3 ps-4 pe-5" type="text"
                                placeholder="Enter your email">
                            <button type="button"
                                class="btn btn-secondary rounded-pill position-absolute top-0 end-0 py-2 mt-2 me-2">Abonnez
                                - vous !</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-white mb-4">Liens rapides</h4>
                        <a href="about.php"><i class="fas fa-angle-right me-2"></i> A propos</a>
                        <a href="cars.php"><i class="fas fa-angle-right me-2"></i> Nos voitures</a>
                        <a href="properties.php"><i class="fas fa-angle-right me-2"></i>Nos propriétés</a>
                        <a href="contact.php"><i class="fas fa-angle-right me-2"></i> Contactez - nous !</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-5">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-white mb-4"> Nos Contacts</h4>
                        <a href="#"><i class="fa fa-map-marker-alt me-2"></i> BP 1517, CENSAD Erevan, Cotonou, Bénin</a>
                        <a href="mailto:oreofechallenges@gmail.com"><i class="fas fa-envelope me-2"></i>
                            oreofechallenges@gmail.com</a>
                        <a href="tel:+012 345 67890"><i class="fas fa-phone me-2"></i> +229 01 943 716 16</a>
                        <a href="tel:+012 345 67890" class="mb-3"><i class="fas fa-print me-2"></i> +229 01 974 474
                            77</a>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-xl-1">
                    <div class="footer-item d-flex flex-column">
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                href="https://m.facebook.com/people/Or%25C3%25A9of%25C3%25AA-Challenges/100088868176677"><i
                                    class="fab fa-facebook-f text-white"></i></a>
                        </div>
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                href="https://www.tiktok.com/%40orofchallenges"><i
                                    class="fab fa-tiktok text-white"></i></a>
                        </div>
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                href="https://www.instagram.com/oreofe_challenges/"><i
                                    class="fab fa-instagram text-white"></i></a>
                        </div>
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-0"
                                href="https://bj.linkedin.com/company/oreofe-challenges"><i
                                    class="fab fa-linkedin-in text-white"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->

    <!-- Copyright Start -->
    <div class="container-fluid copyright py-4">
        <div class="container">
            <div class="row g-4 align-items-center">
                <div class="col-md-8 text-center text-md-start mb-md-0">
                    <span class="text-body"><a href="#" class="border-bottom text-white"><i
                                class="fas fa-copyright text-light me-2"></i>OREOFE CHALLENGES LOCATION DE VOITURES ET
                            HEBERGEMENTS</a>, All right reservés.</span>
                </div>
                <div class="col-md-4 text-center text-md-end text-body">
                    <!--/*** This template is free as long as you keep the below author’s credit link/attribution link/backlink. ***/-->
                    <!--/*** If you'd like to use the template without the below author’s credit link/attribution link/backlink, ***/-->
                    <!--/*** you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". ***/-->
                    Designed By <a class="border-bottom text-white" href="mailto:digitalnative3@gmail.com"> Digital
                        Native</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Copyright End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-secondary btn-lg-square rounded-circle back-to-top"><i class="fa fa-arrow-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>


    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>