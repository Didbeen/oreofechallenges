<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'u214380036_oreofe');
define('DB_PASSWORD', 'JjOVy5F+');
define('DB_NAME', 'u214380036_oreofe');
 
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}



class Database{
    // Connexion à la base de données
    private $host = "localhost";
    private $db_name = "u214380036_oreofe";
    private $username = "u214380036_oreofe";
    private $password = "JjOVy5F+";
    public $connexion;
  
    // getter pour la connexion
    public function getConnection(){
        $this->connexion = null;
        try{
            $this->connexion = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->connexion->exec("set names utf8");
        }catch(PDOException $exception){
            echo "Erreur de connexion : " . $exception->getMessage();
        }
  
        return $this->connexion;
    }   
  }

function car(){
    if (isset($_POST['car'])) {
        $database = new Database();
        $db = $database->getConnection();
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $mark = $_POST['marque'];
        $annee = $_POST['an'];
        $carb = $_POST['carbur'];
        $model = $_POST['model'];
        $desp = $_POST['desc'];        $etat = 1;
        $img = $_FILES['img']['name'];
        $Tname = $_FILES['img']['tmp_name'];
        $ok = "assets/car/".$img;
        $img1 = $_FILES['img1']['name'];
        $Tname1 = $_FILES['img1']['tmp_name'];
        $ok1 = "assets/car/".$img1;
        $img2 = $_FILES['img2']['name'];
        $Tname2 = $_FILES['img2']['tmp_name'];
        $ok2 = "assets/car/".$img2;

        if ($_FILES['img']['error'] == UPLOAD_ERR_OK && $_FILES['img1']['error'] == UPLOAD_ERR_OK && $_FILES['img2']['error'] == UPLOAD_ERR_OK) {
            if (move_uploaded_file($Tname, $ok) && move_uploaded_file($Tname1, $ok1) && move_uploaded_file($Tname2, $ok2)) {
                $sql=$db->prepare("INSERT INTO `cars` (`idc`, `marque`, `modele`, `annee`,`etat`, `img`,`img1`,`img2`, `desc`, `carbur`, `creatat`) 
                VALUES (NULL, :mark, :model, :annee, 1, :img, :img1, :img2, :desp, :carbur, current_timestamp());");
                 $sql->execute(array('mark' => $mark,'model' => $model,'annee' => $annee,'img' => $img,'img1' => $img1,'img2' => $img2,'desp' => $desp,'carbur' => $carb));
    
                if ($sql) {
                    $requ = 1;
                    $_SESSION['message'] = "Véhicule enregistré avec succès ! ...";
                    header('Location: parametre.php?requ='.$requ);
                    exit();
                }else {
                            $_SESSION['message'] = "Echec d\'enrégistrement! ...";
                    header('Location: parametre.php?requ='.$requ);
                    exit();
                }
            }
        }
    }
}

function heberger(){
    
    if (isset($_POST['heb'])) {
        $database = new Database();
        $db = $database->getConnection();
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $typ = trim($_POST['type']);
        $libel = trim($_POST['libel']);
        $adress = trim($_POST['adresse']);
        $nom = trim($_POST['nom']);
        $ville = trim($_POST['vil']);
        $np = trim($_POST['np']);
        $nc = trim($_POST['nc']);
        $etat = 1;
        $imgp = $_FILES['imgp']['name'];
        $Tname = $_FILES['imgp']['tmp_name'];
        $okk = "assets/images/".$imgp;
        $imgs = $_FILES['imgs']['name'];
        $name = $_FILES['imgs']['tmp_name'];
        $ok = "assets/images/".$imgs;
        $img1 = $_FILES['img1']['name'];
        $Tname1 = $_FILES['img1']['tmp_name'];
        $ok1 = "assets/images/".$img1;
        $img2 = $_FILES['img2']['name'];
        $Tname2 = $_FILES['img2']['tmp_name'];
        $ok2 = "assets/images/".$img2;

         if ($_FILES['imgp']['error'] == UPLOAD_ERR_OK && $_FILES['imgs']['error'] == UPLOAD_ERR_OK && $_FILES['img1']['error'] == UPLOAD_ERR_OK && $_FILES['img2']['error'] == UPLOAD_ERR_OK) {
            if (move_uploaded_file($Tname, $okk) && move_uploaded_file($name, $ok) && move_uploaded_file($Tname1, $ok1) && move_uploaded_file($Tname2, $ok2) ) {
                $sql=$db->prepare("INSERT INTO `biens` (`idt`, `nom`, `libel`, `type`, `npiece`, `nchambre`, `adresse`, `ville`, `etat`, `imgp`, `imgs`,`img1`,`img2`, `creatat`) VALUES
                 (NULL, ?,?,?,?,?,?,?,?,?,?,?,?, current_timestamp())");
                 $sql->execute(array($nom, $libel, $typ, $np, $nc, $adress, $ville, $etat, $imgp, $imgs,$img1,$img2));
    
                if ($sql) {
                    $requ = 1;
                            $_SESSION['message'] = "Hébergement enregistré avec succès ! ...";
                    header('Location: parametre.php?requ='.$requ); exit();
                }else {
                    $_SESSION['message'] = "Echec d\'enrégistrement ...";
                    header('Location: parametre.php?requ='.$requ); exit();
                }
            }
         }
    }
}

function commenter(){
    if (isset($_POST['submit'])) {
        $database = new Database();
        $db = $database->getConnection();
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        // var_dump($_POST);

        $nom = $_POST['nom'];
        $prof = $_POST['prof'];
         $mess = $_POST['message'];

            $sql=$db->prepare("INSERT INTO `comment` (`id`, `nom`, `texte`, `profession`, `etat`, `creatat`) 
            VALUES (NULL, :nom, :mess, :prof, 0, current_timestamp()) ");
             $sql->execute(array('nom' => $nom,'mess' => $mess,'prof' => $prof));

            if ($sql) {
                echo '<script>window.alert("Merci pour votre commentaire !");</script>';
                // header('Location: index.html');                
            }else {                
                header('Location: 404.html');    
                echo '<script>window.alert("Echec d\'enrégistrement ...");</script>';
            }
    }
}