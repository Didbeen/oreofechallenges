<?php session_start();
include 'formule.php';

function deletecom($id){
        global $link;
        $ok = mysqli_query($link, "DELETE FROM comment where id=$id");
        if ($ok) {
                $requ = 1;
        $_SESSION['message'] = "Suppression effectuée ! ...";
                header('Location: ../parametre.php?requ='.$requ); exit();
                }
}

// function deletecar($id){
//         global $link;
// $ok = mysqli_query($link, "DELETE FROM cars where idc=$id");
// if ($ok) {
//         $requ = 1;
//         $_SESSION['message'] = "Suppression effectuée ! ...";
//         header('Location: ../parametre.php?requ='.$requ); exit();
//         }
// }

// function deletebien($id){
//         global $link;
// $ok = mysqli_query($link, "DELETE FROM biens where idt=$id");
// if ($ok) {
//         $requ = 1;
//         $_SESSION['message'] = "Suppression effectuée ! ...";
//         header('Location: ../parametre.php?requ='.$requ); exit();
//         }
// }

function deletecar($id){
        global $link;
        $chemin_base_images = $_SERVER['DOCUMENT_ROOT'] . '/assets/car/';
        $sql_select_image = mysqli_query($link, "SELECT img,img1,img2 FROM cars WHERE idc = $id");
        $row = mysqli_fetch_array($sql_select_image, MYSQLI_ASSOC);
    
        $suppression_image_reussie = true;
        $erreurs_suppression_images = [];
        $avertissements_images_inexistantes = [];

        if ($row) {
                $noms_images = [
                $row['img'],
                $row['img1'],
                $row['img2'],
                ];

                // 2. Supprimer chaque fichier image du système de fichiers
                foreach ($noms_images as $nom_fichier) {
                        if ($nom_fichier) {
                            $chemin_fichier_a_supprimer = $chemin_base_images . $nom_fichier;
                        //     var_dump($chemin_fichier_a_supprimer); break;
            
                            if (file_exists($chemin_fichier_a_supprimer)) {
                                if (!unlink($chemin_fichier_a_supprimer)) {
                                    $suppression_images_reussie = false;
                                    $erreurs_suppression_images[] = "Erreur lors de la suppression du fichier : " . $nom_fichier;
                                }
                            } else {
                                $avertissements_images_inexistantes[] = "Le fichier n'existe pas : " . $nom_fichier;
                            }
                        }
                    }

    
            // 3. Supprimer l'enregistrement du produit de la base de données UNIQUEMENT SI la suppression de l'image a réussi (ou si l'image n'existait pas)
            if ($suppression_image_reussie) {
               
                $ok = mysqli_query($link, "DELETE FROM cars where idc=$id");
                if ($ok) {
                        $requ = 1;
                                $_SESSION['message'] = "Suppression effectuée ! ...";
                        header('Location: ../parametre.php?requ='.$requ);exit();
                        }
                } else {
                        echo "Erreur : L'image n'a pas pu être supprimée. Le produit n'a pas été supprimé de la base de données.";
                        if (isset($erreur_suppression_image)) {
                        echo " " . $erreur_suppression_image;
                        }
                }
}}

function deletebien($id){
        global $link;
        $chemin_base_images = $_SERVER['DOCUMENT_ROOT'] . '/assets/images/';
        $sql_select_image = mysqli_query($link, "SELECT imgp,imgs,img1,img2 FROM biens WHERE idt = $id");
        $row = mysqli_fetch_array($sql_select_image, MYSQLI_ASSOC);
    
        $suppression_image_reussie = true;
        $erreurs_suppression_images = [];
        $avertissements_images_inexistantes = [];

        if ($row) {
                $noms_images = [
                $row['imgp'],
                $row['imgs'],
                $row['img1'],
                $row['img2'],
                ];

                // 2. Supprimer chaque fichier image du système de fichiers
                foreach ($noms_images as $nom_fichier) {
                        if ($nom_fichier) {
                            $chemin_fichier_a_supprimer = $chemin_base_images . $nom_fichier;
                            // var_dump($chemin_fichier_a_supprimer);
            
                            if (file_exists($chemin_fichier_a_supprimer)) {
                                if (!unlink($chemin_fichier_a_supprimer)) {
                                    $suppression_images_reussie = false;
                                    $erreurs_suppression_images[] = "Erreur lors de la suppression du fichier : " . $nom_fichier;
                                }
                            } else {
                                $avertissements_images_inexistantes[] = "Le fichier n'existe pas : " . $nom_fichier;
                            }
                        }
                    }

    
            // 3. Supprimer l'enregistrement du produit de la base de données UNIQUEMENT SI la suppression de l'image a réussi (ou si l'image n'existait pas)
            if ($suppression_image_reussie) {
                $ok = mysqli_query($link, "DELETE FROM biens where idt=$id");
                if ($ok) {
                        $requ = 1;
                                $_SESSION['message'] = "Suppression effectuée ! ...";
                        header('Location: ../parametre.php?requ='.$requ); exit();
                        }} else {
                                echo "Erreur : L'image n'a pas pu être supprimée. Le produit n'a pas été supprimé de la base de données.";
                                if (isset($erreur_suppression_image)) {
                                echo " " . $erreur_suppression_image;
                                }
                        }
                }
}

function active($id){
        global $link;
$ok = mysqli_query($link, "UPDATE `biens` SET `etat` = 1 WHERE `biens`.`idt` = $id ");
if ($ok) {
        $requ = 1;
        $_SESSION['message'] = "Activation effectuée ! ...";
        header('Location: ../parametre.php?requ='.$requ); exit();
        }
}

function disable($id){
        global $link;
$ok = mysqli_query($link, "UPDATE `biens` SET `etat` = 0 WHERE `biens`.`idt` = $id ");
if ($ok) {
        $requ = 1;
        $_SESSION['message'] = "Désactivation effectuée ! ...";
        header('Location: ../parametre.php?requ='.$requ); exit();
        }
}
function activec($id){
        global $link;
$ok = mysqli_query($link, "UPDATE `comment` SET `etat` = 1 WHERE `comment`.`id` = $id ");
if ($ok) {
        $requ = 1;
        $_SESSION['message'] = "Activation effectuée ! ...";
        header('Location: ../parametre.php?requ='.$requ);      exit();     
        }
}
function disablec($id){
        global $link;
$ok = mysqli_query($link, "UPDATE `comment` SET `etat` = 0 WHERE `comment`.`id` = $id ");
if ($ok) {
        $requ = 1;
        $_SESSION['message'] = "Désactivation effectuée ! ...";
        header('Location: ../parametre.php?requ='.$requ); exit();
        }
}

function activeca($id){
        global $link;
$ok = mysqli_query($link, "UPDATE `cars` SET `etat` = 1 WHERE `cars`.`idc` = $id ");
if ($ok) {
        $requ = 1;
        $_SESSION['message'] = "Activation effectuée ! ..."; 
        header('Location: ../parametre.php?requ='.$requ);   exit();        
        }
}
function disableca($id){
        global $link;
$ok = mysqli_query($link, "UPDATE `cars` SET `etat` = 0 WHERE `cars`.`idc` = $id ");
if ($ok) {
        $requ = 1;
        $_SESSION['message'] = "Désactivation effectuée ! ...";
        header('Location: ../parametre.php?requ='.$requ); exit();
        }
}

if (isset($_GET['action']) && isset($_GET['id'])) {
        # code...
$action =  $_GET['action'];
$id = $_GET["id"];

switch ($action) {
	case 'deletec' :
	deletecar($id);
	break;
	
	case 'deletecom' :
	deletecom($id);
	break;

	case 'deleteb' :
	deletebien($id);
	break;
	
	case 'active' :
	active($id);
	break;

	case 'disable' :
	disable($id);
	break;

	case 'activec' :
	activec($id);
	break;

	case 'disablec' :
	disablec($id);
	break;

	case 'activeca' :
	activeca($id);
	break;

	case 'disableca' :
	disableca($id);
	break;
	}
}


?>