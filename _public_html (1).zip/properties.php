<?php
include 'forms/formule.php';
  $bien = mysqli_query($link, "SELECT * FROM biens where etat=1"); 
?>
<!DOCTYPE html>
<html lang="fr">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
    rel="stylesheet">

  <title>OREOFE CHALLENGES - IMMOBILIER</title>

  <link href="img/occ.png" rel="icon">
  <link href="img/occ.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


  <!-- Additional CSS Files -->
  <link rel="stylesheet" href="assets/css/fontawesome.css">
  <link rel="stylesheet" href="assets/css/templatemo-villa-agency.css">
  <link rel="stylesheet" href="assets/css/owl.css">
  <link rel="stylesheet" href="assets/css/animate.css">
  <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />
  <!--

TemplateMo 591 villa agency

https://templatemo.com/tm-591-villa-agency

-->
</head>

<body>

  <!-- ***** Preloader Start ***** -->
  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
      </div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->

  <!--<div class="sub-header">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-8">
        <ul class="info">
          <li><i class="fa fa-envelope"></i> info@company.com</li>
          <li><i class="fa fa-map"></i> Sunny Isles Beach, FL 33160</li>
        </ul>
      </div>
      <div class="col-lg-4 col-md-4">
        <ul class="social-links">
          <li><a href="#"><i class="fab fa-facebook"></i></a></li>
          <li><a href="https://x.com/minthu" target="_blank"><i class="fab fa-twitter"></i></a></li>
          <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
          <li><a href="#"><i class="fab fa-instagram"></i></a></li>
        </ul>
      </div>
    </div>
  </div>
</div>

 ***** Header Area Start ***** -->
  <header class="header-area header-sticky">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav">
            <!-- ***** Logo Start ***** -->
            <a href="immobilier.php" class="logo p-3">
              <img src="img/oc.png" alt="OREOFE CHALLENGES" style="width: 200px; height: auto;" class="img-fluid">
            </a>
            <!-- ***** Logo End ***** -->
            <!-- ***** Menu Start ***** -->
            <ul class="nav">
              <li><a href="index.html">Accueil</a></li>
              <li><a href="about.php">A propos</a></li>
              <li><a href="properties.php" class="active">Nos hébergements</a></li>
              <!-- <li><a href="property-details.html">Details du bien</a></li> -->
              <li><a href="contact.php">Contacts</a></li>
              <li><a href="properties.php"><i class="fa fa-calendar"></i> Demander une visite</a></li>
            </ul>
            <a class='menu-trigger'>
              <span>Menu</span>
            </a>
            <!-- ***** Menu End ***** -->
          </nav>
        </div>
      </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->

  <div class="page-heading header-text">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <span class="breadcrumb"><a href="#">Accueil</a> / Proprités</span>
          <h3>Nos Propriétés</h3>
        </div>
      </div>
    </div>
  </div>

    <div class="section properties mb-4">
      <div class="container">
        <ul class="properties-filter">
          <li>
            <a class="is_active" href="#!" data-filter="*">Tout voir</a>
          </li>
          <li>
            <a href="#!" data-filter=".appartement">Appartements</a>
          </li>
          <li>
            <a href="#!" data-filter=".maison">Maisons</a>
          </li>
          <li>
            <a href="#!" data-filter=".menage">Ménages</a>
          </li>
        </ul>

        <div class="row properties-box">
          <?php while ($biens = mysqli_fetch_array($bien, MYSQLI_ASSOC)) { ?>
          <div class="col-lg-4 col-md-6 align-self-center mb-30 properties-items col-md-6 <?= $biens['type'] ?>">
            <div class="item">
              <a href="property-details.php?code=<?= $biens['idt'] ?>"><img src="img/<?= $biens['imgp'] ?>"
              style="max-height: 320px;" alt="<?= $biens['nom'] ?>"></a>
              <span class="category text-capitalize"><?= $biens['type'] ?></span>
              <h6><?= $biens['ville'] ?></h6>
              <h4><a href="property-details.php?code=<?= $biens['idt'] ?>"><?= $biens['adresse'] ?> </a></h4>
              <ul>
                <li>Pièces : <span><?= $biens['npiece'] ?></span></li>
                <li>Chambre : <span><?= $biens['nchambre'] ?></span></li>
                <!-- <li>Surface: <span> m²</span></li> -->
                <!-- <li>Floor: <span>3</span></li>
                <li>Parking: <span>6 spots</span></li> -->
              </ul>
              <div class="main-button">
                <a href="property-details.php?code=<?= $biens['idt'] ?>">Visiter / Réserver</a>
              </div>
            </div>
          </div>
          <?php } ?>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <ul class="pagination">
              <li><a class="is_active" href="#">1</a></li>
              <li><a href="#">2</a></li>
              <li><a href="#">3</a></li>
              <li><a href="#">>></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>



    <!-- Footer Start -->
    <div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <div class="footer-item">
                            <h4 class="text-white mb-4">A propos</h4>
                            <p class="mb-3">Besoin d’une <b>voiture</b> ou d’un <b>appartement</b> ? Contactez-nous dès
                                maintenant pour réserver ou obtenir plus d’informations</p>
                        </div>
                        <div class="position-relative">
                            <input class="form-control rounded-pill w-100 py-3 ps-4 pe-5" type="text"
                                placeholder="Enter your email">
                            <button type="button"
                                class="btn btn-secondary rounded-pill position-absolute top-0 end-0 py-2 mt-2 me-2">Abonnez
                                - vous !</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-white mb-4">Liens rapides</h4>
                        <a href="about.php"><i class="fas fa-angle-right me-2"></i> A propos</a>
                        <a href="cars.php"><i class="fas fa-angle-right me-2"></i> Nos voitures</a>
                        <a href="properties.php"><i class="fas fa-angle-right me-2"></i>Nos propriétés</a>
                        <a href="contact.php"><i class="fas fa-angle-right me-2"></i> Contactez - nous !</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-5">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-white mb-4"> Nos Contacts</h4>
                        <a href="#"><i class="fa fa-map-marker-alt me-2"></i> BP 1517, CENSAD Erevan, Cotonou, Bénin</a>
                        <a href="mailto:oreofechallenges@gmail.com"><i class="fas fa-envelope me-2"></i>
                            oreofechallenges@gmail.com</a>
                        <a href="tel:+012 345 67890"><i class="fas fa-phone me-2"></i> +229 01 943 716 16</a>
                        <a href="tel:+012 345 67890" class="mb-3"><i class="fas fa-print me-2"></i> +229 01 974 474
                            77</a>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-xl-1">
                    <div class="footer-item d-flex flex-column">
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                href="https://m.facebook.com/people/Or%25C3%25A9of%25C3%25AA-Challenges/100088868176677"><i
                                    class="fab fa-facebook-f text-white"></i></a>
                        </div>
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                href="https://www.tiktok.com/%40orofchallenges"><i
                                    class="fab fa-tiktok text-white"></i></a>
                        </div>
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                href="https://www.instagram.com/oreofe_challenges/"><i
                                    class="fab fa-instagram text-white"></i></a>
                        </div>
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-0"
                                href="https://bj.linkedin.com/company/oreofe-challenges"><i
                                    class="fab fa-linkedin-in text-white"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->

    <!-- Copyright Start -->
    <div class="container-fluid copyright py-4">
        <div class="container">
            <div class="row g-4 align-items-center">
                <div class="col-md-8 text-center text-md-start mb-md-0">
                    <span class="text-body"><a href="#" class="border-bottom text-white"><i
                                class="fas fa-copyright text-light me-2"></i>OREOFE CHALLENGES LOCATION DE VOITURES ET
                            HEBERGEMENTS</a>, All right reservés.</span>
                </div>
                <div class="col-md-4 text-center text-md-end text-body">
                    <!--/*** This template is free as long as you keep the below author’s credit link/attribution link/backlink. ***/-->
                    <!--/*** If you'd like to use the template without the below author’s credit link/attribution link/backlink, ***/-->
                    <!--/*** you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". ***/-->
                    Designed By <a class="border-bottom text-white" href="mailto:digitalnative3@gmail.com"> Digital
                        Native</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Copyright End -->

  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/js/isotope.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/counter.js"></script>
  <script src="assets/js/custom.js"></script>

</body>

</html>