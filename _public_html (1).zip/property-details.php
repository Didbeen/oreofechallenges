<?php  include 'forms/formule.php'; 
use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\SMTP;
  use PHPMailer\PHPMailer\Exception;

  require 'PHPMailer/phpmailer/phpmailer/src/Exception.php';
  require 'PHPMailer/phpmailer/phpmailer/src/PHPMailer.php';
  require 'PHPMailer/phpmailer/phpmailer/src/SMTP.php';

$code = $_GET['code']; 
if ($code == "") {
    header('Location: 404.html');
} else {

    $ok = mysqli_query($link, "SELECT * FROM biens where idt='$code'"); 
    $row = mysqli_fetch_array($ok, MYSQLI_ASSOC); 
}
if(isset($_POST['visite'])){
    $nom = $_POST['nom']; $email = $_POST['mail'];
    $jdep = ($_POST['jvis'] != null) ? $_POST['jvis'] : "Non renseigné";
    $hdep = ($_POST['hvis'] != null) ? $_POST['hvis'] : "Non renseigné";
    $tel = ($_POST['tel'] != null) ? $_POST['tel'] : "Non renseigné"; 
            
    try {
                    // Create an instance; passing `true` enables exceptions
            $mail = new PHPMailer(true);
            // Server settings
            $mail->SMTPDebug = 0;
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'oreofechallenges@gmail.com';                     //SMTP username
            $mail->Password   = 'apdrdfvpheydykjb';                               //SMTP password
            $mail->SMTPSecure = 'ssl';            //Enable implicit TLS encryption ENCRYPTION_STARTTLS
            $mail->Port       = 465;                                     //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
            
            //Recipients
            $mail->setFrom($email, $nom);
            $mail->addAddress('oreofechallenges@gmail.com','<b>Demande de visite<b> | Site OREOFE CHALLENGES');  
            //  $mail->addAddress($_POST['email'], $_POST['name']);     //Add a recipient
            // $mail->addAddress('ellen@example.com');               //Name is optional
            $mail->addReplyTo($email, $nom);
            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = 'Demande de visite du propriété : '.$row['nom'];
            $mail->Body    = '<strong> Numero de téléphone :<strong> '.$tel.'
                                    <br><strong> E - Mail :<strong> '.$email.'
                                    <br><strong>Message : <strong> Mr/Mme '.$nom.' demande une visite du propriété '.$row['nom'].'
                                    le '.$jdep.' à '.$hdep.' heures ';
            $mail->AltBody = '<strong>Demande de visite  par de Mr/Mme '.$nom.'<strong>';
            $mail->send();
            echo "<script>window.alert('Visite demandée ! Vous serez recontacté d\'ici peu !')</script>";
            // header('Location: properties.php');
            } catch (Exception $e) {
                    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}"; 
            }
    }

if(isset($_POST['reserver'])){
$nom = $_POST['nome']; $email = $_POST['email'];
$jdep = ($_POST['prise'] != null) ? $_POST['prise'] : "Non renseigné";
$hprise = $_POST['hprise']; $hsortie = ($_POST['hsortie'] != null) ? $_POST['hsortie'] : "Non renseigné";
$sortie = ($_POST['sortie'] != null) ? $_POST['sortie'] : "Non renseigné";
$tel = ($_POST['tele'] != null) ? $_POST['tele'] : "Non renseigné";
//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = 0;
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'oreofechallenges@gmail.com';                     //SMTP username
    $mail->Password   = 'apdrdfvpheydykjb';                               //SMTP password
    $mail->SMTPSecure = 'ssl';            //Enable implicit TLS encryption ENCRYPTION_STARTTLS
    $mail->Port       = 465;                             //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom($email, $nom);
    $mail->addAddress('oreofechallenges@gmail.com','<b>Réservation de propriété <b> | Site OREOFE CHALLENGES');  
    //  $mail->addAddress($_POST['email'], $_POST['name']);     //Add a recipient
    // $mail->addAddress('ellen@example.com');               //Name is optional
    $mail->addReplyTo($email, $nom);
    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Réservation du propriété :'.$row['nom'];
    $mail->Body    = '<strong> Numero de téléphone :<strong> '.$tel.'
                        <br><strong> E - Mail :<strong> '.$email.'
                        <br><strong>Message : <strong> Mr/Mme '.$nom.' réserve la propriété '.$row['nom'].'  
                            le '.$jdep.' à '.$hprise.' heures jusqu\'au  '.$sortie.' à '.$hsortie;
    $mail->AltBody = '<strong>Demande de visite  par de Mr/Mme '.$nom.'<strong>';
    $mail->send();
    echo "<script>alert('Réservation Envoyée ! Vous serez recontacté d\'ici peu !')</script>";
    } catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}"; 
    }
}

  ?>
<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">

    <title>OREOFE CHALLENGES - IMMOBILIER</title>

    <link href="img/occ.png" rel="icon">
    <link href="img/occ.png" rel="apple-touch-icon">

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-villa-agency.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />
    <!--

TemplateMo 591 villa agency

https://templatemo.com/tm-591-villa-agency

-->
</head>

<body>

    <!-- ***** Preloader Start ***** -->
    <div id="js-preloader" class="js-preloader">
        <div class="preloader-inner">
            <span class="dot"></span>
            <div class="dots">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </div>
    <!-- ***** Preloader End ***** -->

    <!-- ***** Header Area Start ***** -->
    <header class="header-area header-sticky">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav">
                        <!-- ***** Logo Start ***** -->
                        <a href="immobilier.php" class="logo p-3">
                            <img src="img/oc.png" alt="OREOFE CHALLENGES" style="width: 200px; height: auto;"
                                class="img-fluid">
                        </a>
                        <!-- ***** Logo End ***** -->
                        <!-- ***** Menu Start ***** -->
                        <ul class="nav">
                            <li><a href="index.html">Accueil</a></li>
                            <li><a href="about.php">A propos</a></li>
                            <li><a href="properties.php" class="active">Nos hébergements</a></li>
                            <li><a href="contact.php">Contacts</a></li>
                            <li><a href="properties.php"><i class="fa fa-calendar"></i> Demander une visite</a></li>
                        </ul>
                        <a class='menu-trigger'>
                            <span>Menu</span>
                        </a>
                        <!-- ***** Menu End ***** -->
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** Header Area End ***** -->
    <div class="page-heading header-text">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <span class="breadcrumb"><a href="#">Accueil</a> / Propriété
                        <?= $row['nom'] ?>
                    </span>
                    <h3 class="text-capitalize">
                        <?= $row['nom'] ?> à
                        <?= $row['ville'] ?>
                    </h3>
                </div>
            </div>
        </div>
    </div>

    <div class="single-property section mb-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div id="carouselId" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000">
                        <ol class="carousel-indicators">
                            <li data-bs-target="#carouselId" data-bs-slide-to="0" class="active" aria-current="true"
                                aria-label="First slide"></li>
                            <li data-bs-target="#carouselId" data-bs-slide-to="1" aria-label="Second slide"></li>
                            <li data-bs-target="#carouselId" data-bs-slide-to="2" aria-label="Third slide"></li>
                        </ol>
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active">
                                <img src="assets/images/<?= $row['imgs'] ?>" 
                                    class="img-fluid " alt="First slide" />
                            </div>
                            <div class="carousel-item">
                                <img src="assets/images/<?= $row['img1'] ?>"
                                    class="img-fluid " alt="Second slide" />
                            </div>
                            <div class="carousel-item">
                                <img src="assets/images/<?= $row['img2'] ?>"
                                    class="img-fluid " alt="Third slide" />
                            </div>
                        </div>
                    </div>
                            <div class="main-content mb-4">
                                <span class="category text-capitalize">
                                    <?= $row['ville'] ?>
                                </span>  
                                <h5 class="text-align-justify">
                                    <?= $row['adresse'] ?> ||
                                    <?= $row['libel'] ?>
                                    <div class="row"></div>
                                </h5>
                             </div>

                    <!-- Modal End -->
                    <div class="accordion" id="accordionExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    <b>Qui sommes - nous ?</b>
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Chez <strong><a href="index.php" target="_blank">OREOFE
                                            CHALLENGES</a></strong> nous croyons en la responsabilité sociale.
                                    En plus de fournir des services de classe mondiale, nous nous engageons à donner en
                                    retour
                                    aux communautés que nous desservons. Nos initiatives sociales visent à créer un
                                    impact positif,
                                    de la réduction de notre <b>empreinte carbone</b> à la contribution à des causes
                                    sociales.<a href="contact.php">Contactez-nous</a> pour organiser une visite</div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    <b>Comment ça marche ?</b>
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Gràce à notre <strong>plateforme disponnible en ligne</strong>, vous trouverez
                                    rapidement le bien qui
                                    correspond à vos besoins.
                                    Nous sommes à l'écoute de vos <code>projets</code> et nous nous adaptons à vos
                                    envies.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    <b>Pourquoi sommes - nous les meileurs ?</b>
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body"> Nous offrons un service de <code>location
                                    d’appartements</code> qui répond à tous vos besoins. Nos appartements sont soigneusement
                                    sélectionnés pour leur <b>confort, leur sécurité et leur accessibilité</b>. Que vous
                                    soyez
                                    en <code>voyage d’affaires, en vacances ou en transition entre deux logements</code>, nous avons
                                    l’appartement idéal pour vous. Nos logements sont entièrement équipés et
                                    <strong>meublés</strong>, offrant toutes les commodités
                                    nécessaires pour un <strong>séjour agréable</strong>. De plus, nous proposons une gamme variée
                                    d’appartements, allant des <b>studios aux spacieux appartements familiaux</b>, situés dans
                                    des quartiers prisés et bien desservis de <code>Cotonou et Calavi</code>.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    
                    <div class="main-image " style="margin-bottom : 50px;">
                        <img src="img/<?= $row['imgp'] ?>" alt="">
                        <div class="main-button text-center m-3" id="breserver"><a href="#!">Réservation</a></div>
                        <div class="main-button text-center m-3" id="bvisite"><a href="#!">Demander une visite</a></div>
                    </div>
                    <!-- Modal -->
                    <div class="modal-content w-100 bg-light " id="mvisite" style="display: none;">
                        <div class="modal-header text-center" style="background : #f35525">
                            <h5 class="modal-title" id="modalVisite">Demande de visite :
                                <?= $row['nom'] ?>
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body p-4">
                            <form action="" method="POST" role="form" class="sign-up-form ">
                                <!-- Name input -->
                                <div class="row g-3">
                                    <div class="col-12">
                                        <a href="#" class="text-start text-red d-block mb-2">Précisez l'horaire de
                                            visite</a>
                                            <div
                                                class="d-flex align-items-center bg-light text-body rounded-start p-auto">
                                                <span class="fas fa-map-marker-alt"></span><span class="ms-1">Date
                                                    :</span>
                                            </div>
                                            <input class="form-control" name="jvis" id="jvis" type="date" required>
                                            <input class="form-control mt-3" type="time" name="hvis" id="hvis" required>
                                    </div>
                                    <div class="col-12">
                                                <input class="form-control mt-3" type="email" name="mail" id="mail"
                                                    pattern="[^ @]*@[^ @]*" placeholder="Votre E-mail..." required>
                                            
                                                <input class="form-control mt-3" type="phone" name="tel" id="tel"
                                                    placeholder="Entrer votre numéro de téléphone" required>
                                    </div>
                                    <div class="col-12">
                                        <input class="form-control mt-3" type="text" name="nom" id="nom"
                                            placeholder="Entrer votre nom et prénoms" required>

                                    </div>

                                    <!-- Submit button -->
                                    <button type="submit" name="visite" id="visite"
                                        class="btn btn-dark text-center">Confirmer</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- Modal End -->

                    <!-- Modal -->
                    <div class="modal-content w-100 bg-light" id="mreserver" style="display: none;">
                        <div class="modal-header text-center" style="background : #f35525;">
                            <h5 class="modal-title" id="modalReservation">Réservation :
                                <?= $row['nom'] ?>
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body p-4">
                            <form action="" method="POST" role="form" class="sign-up-form ">
                                <!-- Name input -->
                                <div class="row g-3">
                                    <div class="col-12">
                                        <a href="#" class="text-start text-red d-block mb-2">Précisez la durée de
                                            location</a>
                                            <div
                                                class="d-flex align-items-center bg-light text-body rounded-start mt-3">
                                                <span class="ms-1">Date d'entrée :</span>
                                            </div>
                                        <div class="input-group">
                                            <input class="form-control" name="prise" id="prise" type="date" required>
                                            <input class="form-control ms-3" type="time" name="hprise" id="hprise"
                                                required>
                                        </div>
                                            <div
                                                class="d-flex align-items-center bg-light text-body rounded-start mt-3">
                                                <span class="ms-1">Date de sortie :</span>
                                            </div>
                                        <div class="input-group">
                                            <input class="form-control" name="sortie" id="sortie" type="date">
                                            <input class="form-control ms-3" type="time" name="hsortie" id="hsortie">
                                        </div>
                                    </div>
                                    <div class="col-12">
                                                <input class="form-control" type="email" name="email" id="email"
                                                    pattern="[^ @]*@[^ @]*" placeholder="Votre E-mail..." required>
                                    </div>
                                    <div class="col-12">
                                                <input class="form-control" type="phone" name="tele" id="tele"
                                                    placeholder="Entrer votre numéro de téléphone" required>
                                    </div>
                                    <div class="col-12">
                                        <input class="form-control col-lg-6 " type="text" name="nome" id="nome"
                                            placeholder="Entrer votre nom et prénoms" required>
                                        <!-- <input class="form-check-label" name="remember" type="checkbox"
                                    style="border: 1px solid;">
                                <label class="form-check-label" for="gridCheck" >
                                    J'accepte les frais de visite
                                </label> -->

                                    </div>

                                    <!-- Submit button -->
                                    <button type="submit" name="reserver" id="reserver"
                                        class="btn btn-dark text-center">Réserver</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        document.getElementById('bvisite').addEventListener('click', function () {
            document.getElementById('mreserver').style.display = 'none';
            document.getElementById('mvisite').style.display = 'block';
        });

        document.getElementById('breserver').addEventListener('click', function () {
            document.getElementById('mreserver').style.display = 'block';
            document.getElementById('mvisite').style.display = 'none';
        });
    </script>
    <!-- <div class="section best-deal">
    <div class="container">
      <div class="row">
        <div class="col-lg-4">
          <div class="section-heading">
            <h6>| Meilleure Echange</h6>
            <h2>Find Your Best Deal Right Now!</h2>
          </div>
        </div>
        <div class="col-lg-12">
          <div class="tabs-content">
            <div class="row">
              <div class="nav-wrapper ">
                <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="appartment-tab" data-bs-toggle="tab"
                      data-bs-target="#appartment" type="button" role="tab" aria-controls="appartment"
                      aria-selected="true">Appartment</button>
                  </li>
                  <li class="nav-item" role="presentation">
                    <button class="nav-link" id="villa-tab" data-bs-toggle="tab" data-bs-target="#villa" type="button"
                      role="tab" aria-controls="villa" aria-selected="false">Villa House</button>
                  </li>
                  <li class="nav-item" role="presentation">
                    <button class="nav-link" id="penthouse-tab" data-bs-toggle="tab" data-bs-target="#penthouse"
                      type="button" role="tab" aria-controls="penthouse" aria-selected="false">Penthouse</button>
                  </li>
                </ul>
              </div>
              <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="appartment" role="tabpanel" aria-labelledby="appartment-tab">
                  <div class="row">
                    <div class="col-lg-3">
                      <div class="info-table">
                        <ul>
                          <li>Total Flat Space <span>540 m2</span></li>
                          <li>Floor number <span>3</span></li>
                          <li>Number of rooms <span>8</span></li>
                          <li>Parking Available <span>Yes</span></li>
                          <li>Payment Process <span>Bank</span></li>
                        </ul>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <img src="assets/images/deal-01.jpg" alt="">
                    </div>
                    <div class="col-lg-3">
                      <h4>All Info About Apartment</h4>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, do eiusmod tempor pack incididunt ut
                        labore et dolore magna aliqua quised ipsum suspendisse. <br><br>Swag fanny pack lyft blog twee.
                        JOMO ethical copper mug, succulents typewriter shaman DIY kitsch twee taiyaki fixie hella venmo
                        after messenger poutine next level humblebrag swag franzen.</p>
                      <div class="icon-button">
                        <a href="#"><i class="fa fa-calendar"></i> Schedule a visit</a>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="tab-pane fade" id="villa" role="tabpanel" aria-labelledby="villa-tab">
                  <div class="row">
                    <div class="col-lg-3">
                      <div class="info-table">
                        <ul>
                          <li>Total Flat Space <span>250 m2</span></li>
                          <li>Floor number <span>26th</span></li>
                          <li>Number of rooms <span>5</span></li>
                          <li>Parking Available <span>Yes</span></li>
                          <li>Payment Process <span>Bank</span></li>
                        </ul>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <img src="assets/images/deal-02.jpg" alt="">
                    </div>
                    <div class="col-lg-3">
                      <h4>Detail Info About New Villa</h4>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, do eiusmod tempor pack incididunt ut
                        labore et dolore magna aliqua quised ipsum suspendisse. <br><br>Swag fanny pack lyft blog twee.
                        JOMO ethical copper mug, succulents typewriter shaman DIY kitsch twee taiyaki fixie hella venmo
                        after messenger poutine next level humblebrag swag franzen.</p>
                      <div class="icon-button">
                        <a href="#"><i class="fa fa-calendar"></i> Schedule a visit</a>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="tab-pane fade" id="penthouse" role="tabpanel" aria-labelledby="penthouse-tab">
                  <div class="row">
                    <div class="col-lg-3">
                      <div class="info-table">
                        <ul>
                          <li>Total Flat Space <span>320 m2</span></li>
                          <li>Floor number <span>34th</span></li>
                          <li>Number of rooms <span>6</span></li>
                          <li>Parking Available <span>Yes</span></li>
                          <li>Payment Process <span>Bank</span></li>
                        </ul>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <img src="assets/images/deal-03.jpg" alt="">
                    </div>
                    <div class="col-lg-3">
                      <h4>Extra Info About Penthouse</h4>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, do eiusmod tempor pack incididunt ut
                        Kinfolk tonx seitan crucifix 3 wolf moon bicycle rights keffiyeh snackwave wolf same vice,
                        chillwave vexillologistlabore et dolore magna aliqua quised ipsum suspendisse. <br><br>Swag
                        fanny pack lyft blog twee. JOMO ethical copper mug, succulents typewriter shaman DIY kitsch twee
                        taiyaki fixie hella venmo after messenger poutine next level humblebrag swag franzen.</p>
                      <div class="icon-button">
                        <a href="#"><i class="fa fa-calendar"></i> Schedule a visit</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div> -->


    <!-- Footer Start -->
    <div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <div class="footer-item">
                            <h4 class="text-white mb-4">A propos</h4>
                            <p class="mb-3">Besoin d’une <b>voiture</b> ou d’un <b>appartement</b> ? Contactez-nous dès
                                maintenant pour réserver ou obtenir plus d’informations</p>
                        </div>
                        <div class="position-relative">
                            <input class="form-control rounded-pill w-100 py-3 ps-4 pe-5" type="text"
                                placeholder="Enter your email">
                            <button type="button"
                                class="btn btn-secondary rounded-pill position-absolute top-0 end-0 py-2 mt-2 me-2">Abonnez
                                - vous !</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-white mb-4">Liens rapides</h4>
                        <a href="about.php"><i class="fas fa-angle-right me-2"></i> A propos</a>
                        <a href="cars.php"><i class="fas fa-angle-right me-2"></i> Nos voitures</a>
                        <a href="properties.php"><i class="fas fa-angle-right me-2"></i>Nos propriétés</a>
                        <a href="contact.php"><i class="fas fa-angle-right me-2"></i> Contactez - nous !</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-5">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-white mb-4"> Nos Contacts</h4>
                        <a href="#"><i class="fa fa-map-marker-alt me-2"></i> BP 1517, CENSAD Erevan, Cotonou, Bénin</a>
                        <a href="mailto:oreofechallenges@gmail.com"><i class="fas fa-envelope me-2"></i>
                            oreofechallenges@gmail.com</a>
                        <a href="tel:+012 345 67890"><i class="fas fa-phone me-2"></i> +229 01 943 716 16</a>
                        <a href="tel:+012 345 67890" class="mb-3"><i class="fas fa-print me-2"></i> +229 01 974 474
                            77</a>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-xl-1">
                    <div class="footer-item d-flex flex-column">
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                href="https://m.facebook.com/people/Or%25C3%25A9of%25C3%25AA-Challenges/100088868176677"><i
                                    class="fab fa-facebook-f text-white"></i></a>
                        </div>
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                href="https://www.tiktok.com/%40orofchallenges"><i
                                    class="fab fa-tiktok text-white"></i></a>
                        </div>
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                href="https://www.instagram.com/oreofe_challenges/"><i
                                    class="fab fa-instagram text-white"></i></a>
                        </div>
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-0"
                                href="https://bj.linkedin.com/company/oreofe-challenges"><i
                                    class="fab fa-linkedin-in text-white"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->

    <!-- Copyright Start -->
    <div class="container-fluid copyright py-4">
        <div class="container">
            <div class="row g-4 align-items-center">
                <div class="col-md-8 text-center text-md-start mb-md-0">
                    <span class="text-body"><a href="#" class="border-bottom text-white"><i
                                class="fas fa-copyright text-light me-2"></i>OREOFE CHALLENGES LOCATION DE VOITURES ET
                            HEBERGEMENTS</a>, All right reservés.</span>
                </div>
                <div class="col-md-4 text-center text-md-end text-body">
                    <!--/*** This template is free as long as you keep the below author’s credit link/attribution link/backlink. ***/-->
                    <!--/*** If you'd like to use the template without the below author’s credit link/attribution link/backlink, ***/-->
                    <!--/*** you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". ***/-->
                    Designed By <a class="border-bottom text-white" href="mailto:digitalnative3@gmail.com"> Digital
                        Native</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Copyright End -->


    <!-- Scripts -->
    <!-- Bootstrap core JavaScript -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/isotope.min.js"></script>
    <script src="assets/js/owl-carousel.js"></script>
    <script src="assets/js/counter.js"></script>
    <script src="assets/js/custom.js"></script>

</body>

</html>