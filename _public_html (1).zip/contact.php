<?php 
include_once 'forms/formule.php';
if(!empty($_POST)){
  extract($_POST);
  commenter();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
    rel="stylesheet">

  <title>OREOFE CHALLENGES - IMMOBILIER</title>
  <link href="img/occ.png" rel="icon">
  <link href="img/occ.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


  <!-- Additional CSS Files -->
  <link rel="stylesheet" href="assets/css/fontawesome.css">
  <link rel="stylesheet" href="assets/css/templatemo-villa-agency.css">
  <link rel="stylesheet" href="assets/css/owl.css">
  <link rel="stylesheet" href="assets/css/animate.css">
  <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />
  <!--

    -->
</head>

<body>

  <!-- ***** Preloader Start ***** -->
  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->

  <!--<div class="sub-header">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-md-8">
            <ul class="info">
              <li><i class="fa fa-envelope"></i> info@company.com</li>
              <li><i class="fa fa-map"></i> Sunny Isles Beach, FL 33160</li>
            </ul>
          </div>
          <div class="col-lg-4 col-md-4">
            <ul class="social-links">
              <li><a href="#"><i class="fab fa-facebook"></i></a></li>
              <li><a href="https://x.com/minthu" target="_blank"><i class="fab fa-twitter"></i></a></li>
              <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
              <li><a href="#"><i class="fab fa-instagram"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    ***** Header Area Start ***** -->
  <header class="header-area header-sticky">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav">
            <!-- ***** Logo Start ***** -->
            <a href="index.html" class="logo p-3">
              <img src="img/oc.png" alt="OREOFE CHALLENGES" style="width: 200px; height: auto;" class="img-fluid">
            </a>
            <!-- ***** Logo End ***** -->
            <!-- ***** Menu Start ***** -->
            <ul class="nav">
              <li><a href="index.php">Accueil</a></li>
              <li><a href="about.php">A propos</a></li>
              <li><a href="properties.php">Nos hébergements</a></li>
              <li><a href="contact.php" class="active">Contacts</a></li>
              <li><a href="properties.php"><i class="fa fa-calendar"></i> Demander une visite</a></li>
            </ul>
            <a class='menu-trigger'>
              <span>Menu</span>
            </a>
            <!-- ***** Menu End ***** -->
          </nav>
        </div>
      </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->

  <div class="page-heading header-text">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <span class="breadcrumb"><a href="#">Accueil</a> / Contacts</span>
          <h3>Contactez-Nous</h3>
        </div>
      </div>
    </div>
  </div>

  <div class="contact-page section">
    <div class="container">
      <div class="row">
        <div class="col-lg-8">
          <div class="section-heading">
            <h6>| Contactez - Nous</h6>
            <h4>Contactez-nous dès maintenant pour réserver ou obtenir plus d’informations.</h4>
          </div>
          <p>Chez OREOFE-CHALLENGES, notre équipe est le cœur battant de notre succès. Composée d'experts passionnés
            dans l'industrie du transport, chaque membre apporte une expertise unique, garantissant que chaque client
            reçoit un service exceptionnel. Notre équipe dévouée va au-delà des attentes pour créer des expériences
            personnalisées, s'assurant que chaque expérience avec OREOFE-CHALLENGES est une aventure inoubliable.</p>
          <div class="row">
            <div class="col-lg-6">
              <div class="item phone">
                <img src="assets/images/phone-icon.png" alt="" style="max-width: 52px;">
                <h6>+229 01 943 716 16<br><span>Numéro de Téléphone</span></h6>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="item email">
                <img src="assets/images/email-icon.png" alt="" style="max-width: 52px;">
                <h6>oreofe...@gmail.com<br><span>Business Email</span></h6>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <form id="contact-form" action="" method="POST">
            <h5>Rédigez un commentaire !</h5>
            <div class="row mt-3">
              <div class="col-lg-6">
                <fieldset>
                  <label for="name">Nom Complet</label>
                  <input type="name" name="nom" id="nom" placeholder="Votre Nom et Prénoms..." autocomplete="on"
                    required>
                </fieldset>
              </div>
              <div class="col-lg-6">
                <fieldset>
                  <label for="phone">Profession</label>
                  <input type="text" name="prof" id="prof" placeholder="Votre profession..." autocomplete="on">
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <label for="message">Commentaire</label>
                  <textarea name="message" id="message" placeholder="Votre Avis..."></textarea>
                </fieldset>
              </div>
              <div class="col-lg-12">
                <button type="submit" name="submit" class="orange-button">Envoyer un Message</button>
              </div>
            </div>
          </form>
        </div>
        <div class="col-lg-12">
          <div id="map">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3815.6102572019086!2d2.3816541!3d6.3495817!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x25d8e227d0d90cdd%3A0xf5a89b41f941ed9a!2sLOCATION%20DE%20VOITURE%20(Oreofe%20Challenges)!5e1!3m2!1sfr!2sbj!4v1738337689595!5m2!1sfr!2sbj"
              width="100%" height="500px" frameborder="0"
              style="border:0; border-radius: 10px; box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.15);"
              allowfullscreen=""></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>


    <!-- Footer Start -->
      <div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s">
          <div class="container py-5">
              <div class="row g-5">
                  <div class="col-md-6 col-lg-6 col-xl-3">
                      <div class="footer-item d-flex flex-column">
                          <div class="footer-item">
                              <h4 class="text-white mb-4">A propos</h4>
                              <p class="mb-3">Besoin d’une <b>voiture</b> ou d’un <b>appartement</b> ? Contactez-nous dès
                                  maintenant pour réserver ou obtenir plus d’informations</p>
                          </div>
                          <div class="position-relative">
                              <input class="form-control rounded-pill w-100 py-3 ps-4 pe-5" type="text"
                                  placeholder="Enter your email">
                              <button type="button"
                                  class="btn btn-secondary rounded-pill position-absolute top-0 end-0 py-2 mt-2 me-2">Abonnez
                                  - vous !</button>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-6 col-lg-6 col-xl-3">
                      <div class="footer-item d-flex flex-column">
                          <h4 class="text-white mb-4">Liens rapides</h4>
                          <a href="about.php"><i class="fas fa-angle-right me-2"></i> A propos</a>
                          <a href="cars.php"><i class="fas fa-angle-right me-2"></i> Nos voitures</a>
                          <a href="properties.php"><i class="fas fa-angle-right me-2"></i>Nos propriétés</a>
                          <a href="contact.php"><i class="fas fa-angle-right me-2"></i> Contactez - nous !</a>
                      </div>
                  </div>
                  <div class="col-md-6 col-lg-6 col-xl-5">
                      <div class="footer-item d-flex flex-column">
                          <h4 class="text-white mb-4"> Nos Contacts</h4>
                          <a href="#"><i class="fa fa-map-marker-alt me-2"></i> BP 1517, CENSAD Erevan, Cotonou, Bénin</a>
                          <a href="mailto:oreofechallenges@gmail.com"><i class="fas fa-envelope me-2"></i>
                              oreofechallenges@gmail.com</a>
                          <a href="tel:+012 345 67890"><i class="fas fa-phone me-2"></i> +229 01 943 716 16</a>
                          <a href="tel:+012 345 67890" class="mb-3"><i class="fas fa-print me-2"></i> +229 01 974 474
                              77</a>
                      </div>
                  </div>
                  <div class="col-md-3 col-lg-3 col-xl-1">
                      <div class="footer-item d-flex flex-column">
                          <div class="mb-3">
                              <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                  href="https://m.facebook.com/people/Or%25C3%25A9of%25C3%25AA-Challenges/100088868176677"><i
                                      class="fab fa-facebook-f text-white"></i></a>
                          </div>
                          <div class="mb-3">
                              <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                  href="https://www.tiktok.com/%40orofchallenges"><i
                                      class="fab fa-tiktok text-white"></i></a>
                          </div>
                          <div class="mb-3">
                              <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                  href="https://www.instagram.com/oreofe_challenges/"><i
                                      class="fab fa-instagram text-white"></i></a>
                          </div>
                          <div class="mb-3">
                              <a class="btn btn-secondary btn-md-square rounded-circle me-0"
                                  href="https://bj.linkedin.com/company/oreofe-challenges"><i
                                      class="fab fa-linkedin-in text-white"></i></a>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    <!-- Footer End -->

    <!-- Copyright Start -->
    <div class="container-fluid copyright py-4">
        <div class="container">
            <div class="row g-4 align-items-center">
                <div class="col-md-8 text-center text-md-start mb-md-0">
                    <span class="text-body"><a href="#" class="border-bottom text-white"><i
                                class="fas fa-copyright text-light me-2"></i>OREOFE CHALLENGES LOCATION DE VOITURES ET
                            HEBERGEMENTS</a>, All right reservés.</span>
                </div>
                <div class="col-md-4 text-center text-md-end text-body">
                    <!--/*** This template is free as long as you keep the below author’s credit link/attribution link/backlink. ***/-->
                    <!--/*** If you'd like to use the template without the below author’s credit link/attribution link/backlink, ***/-->
                    <!--/*** you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". ***/-->
                    Designed By <a class="border-bottom text-white" href="mailto:digitalnative3@gmail.com"> Digital
                        Native</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Copyright End -->

  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/js/isotope.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/counter.js"></script>
  <script src="assets/js/custom.js"></script>

</body>

</html>