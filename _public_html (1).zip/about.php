<?php include 'forms/formule.php'; 
        ob_start();
        $requ = 0;
        
    if(!empty($_POST)){
        extract($_POST);
        
        if(isset($_POST['submit']) && $_POST['nom'] == 'CHALLENGES'){
        // var_dump($_POST);
        $requ = 1;
        header('Location: parametre.php?requ='.$requ);
        } else {
            $requ = 0;
            ob_end_flush();
            header('Location: index.html');
        }}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Oreofe Challenges - Location de voitures</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">


    <!-- Favicons -->
    <link href="img/occ.png" rel="icon">
    <link href="img/occ.png" rel="apple-touch-icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,400;0,700;0,900;1,400;1,700;1,900&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    <!-- Spinner Start  -->
    <!-- <div id="spinner"
        class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">...</span>
        </div>
    </div> -->
    <!-- Spinner End -->

    <!--
            <div class="container-fluid topbar bg-secondary d-none d-xl-block w-100">
                <div class="container">
                    <div class="row gx-0 align-items-center" style="height: 45px;">
                        <div class="col-lg-6 text-center text-lg-start mb-lg-0">
                            <div class="d-flex flex-wrap">
                                <a href="#" class="text-muted me-4"><i class="fas fa-map-marker-alt text-primary me-2"></i>Find A Location</a>
                                <a href="tel:+01234567890" class="text-muted me-4"><i class="fas fa-phone-alt text-primary me-2"></i>+01234567890</a>
                                <a href="mailto:example@gmail.com" class="text-muted me-0"><i class="fas fa-envelope text-primary me-2"></i>Example@gmail.com</a>
                            </div>
                        </div>
                        <div class="col-lg-6 text-center text-lg-end">
                            <div class="d-flex align-items-center justify-content-end">
                                <a href="#" class="btn btn-light btn-sm-square rounded-circle me-3"><i class="fab fa-facebook-f"></i></a>
                                <a href="#" class="btn btn-light btn-sm-square rounded-circle me-3"><i class="fab fa-twitter"></i></a>
                                <a href="#" class="btn btn-light btn-sm-square rounded-circle me-3"><i class="fab fa-instagram"></i></a>
                                <a href="#" class="btn btn-light btn-sm-square rounded-circle me-0"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                </div> -->
    <!-- Topbar End -->

    <!-- Navbar & Hero Start -->
    <div class="container-fluid nav-bar sticky-top px-0 px-lg-4 py-lg-0">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a href="index.php" class="navbar-brand p-1">
                    <img src="img/oc.png" alt="Logo">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="fa fa-bars"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav mx-auto py-0">
                        <a href="index.html" class="nav-item nav-link ">Accueil</a>
                        <a href="about.php" class="nav-item nav-link active">A propos</a>
                        <a href="cars.php" class="nav-item nav-link"> Nos véhicules</a>
                        <a href="properties.php" class="nav-item nav-link">Nos hébergements</a>

                        <!-- <div class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                                    <div class="dropdown-menu m-0">
                                        <a href="feature.html" class="dropdown-item">Fonctionalités</a>
                                        <a href="cars.html" class="dropdown-item">Voitures</a>
                                        <a href="team.html" class="dropdown-item">Notre équipe</a>
                                        <a href="testimonial.html" class="dropdown-item">Témoignages</a>
                                        <a href="404.html" class="dropdown-item">404 Page</a>
                                    </div>
                                </div> -->
                        <a href="contact.php" class="nav-item nav-link">Contacts</a>
                    </div>
                </div>
                <a href="immobilier.html" class="display-7 text-secondary "><i class="fas fa-home me-3"></i><b>Besoin
                        d'hébergement ?</b></i></a>
            </nav>
        </div>
    </div>
    <!-- Navbar & Hero End -->

    <!-- Header Start -->
    <div class="container-fluid bg-breadcrumb">
        <div class="container text-center py-5" style="max-width: 900px;">
            <h4 class="text-white display-4 mb-4 wow fadeInDown" data-wow-delay="0.1s"> A Propos</h4>
            <ol class="breadcrumb d-flex justify-content-center mb-0 wow fadeInDown" data-wow-delay="0.3s">
                <li class="breadcrumb-item"><a href="index.html">Accueil</a></li>
                <li class="breadcrumb-item"><a href="#">Pages</a></li>
                <li class="breadcrumb-item active text-primary">A Propos</li>
            </ol>
        </div>
    </div>
    <!-- Header End -->

    <!-- About Start -->
    <div class="container-fluid overflow-hidden about py-5">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-xl-6 wow fadeInLeft" data-wow-delay="0.2s">
                    <div class="about-item">
                        <div class="pb-5">
                            <h1 class="display-5 text-capitalize">A <span class="text-primary">propos</span></h1>
                            <p class="mb-0">
                            <h4>Bienvenue chez <b>OREOFE CHALLENGES</b> ! </h4> Notre équipe est le cœur battant de
                            notre succès.
                            Composée d'experts passionnés dans l'industrie du transport, chaque membre apporte une
                            expertise unique,
                            garantissant que chaque client reçoit un service exceptionnel. </p>
                        </div>
                        <div class="row g-4">
                            <div class="col-lg-6">
                                <div class="about-item-inner border p-4">
                                    <div class="about-icon mb-4">
                                        <img src="img/about-icon-1.png" class="img-fluid w-50 h-50" alt="Icon">
                                    </div>
                                    <h5 class="mb-3">Notre Histoire</h5>
                                    <p class="mb-0">L'histoire d'OREOFE-CHALLENGES débute avec une vision audacieuse de
                                        redéfinir le
                                        luxe dans l'industrie du transport.</p>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="about-item-inner border p-4">
                                    <div class="about-icon mb-4">
                                        <img src="img/about-icon-2.png" class="img-fluid h-50 w-50" alt="Icon">
                                    </div>
                                    <h5 class="mb-3">Notre Mission</h5>
                                    <p class="mb-0">Notre mission est de fournir des
                                        solutions de mobilité et d’hébergement de haute qualité qui répondent aux
                                        besoins diversifiés de nos clients. </p>
                                </div>
                            </div>
                        </div>
                        <p class="text-item my-4"> Nous sommes spécialisés dans la location de voitures, offrant une
                            large gamme de véhicules pour répondre à tous vos besoins. Que vous ayez besoin d’une
                            voiture pour un voyage d’affaires, des vacances en famille ou un événement spécial, nous
                            avons ce qu’il vous faut. Explorez également nos services de
                            location d’appartements, vente et importation de véhicules neufs ou d’occasion, vente de
                            pièces détachées, ainsi que nos services de transit et consignation. Votre
                            satisfaction est notre priorité !
                        </p>
                        <div class="row g-4">
                            <div class="col-lg-6">
                                <div class="text-center rounded bg-secondary p-4">
                                    <h1 class="display-6 text-white">3</h1>
                                    <h5 class="text-light mb-0">Années d'Experience</h5>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="rounded">
                                    <p class="mb-2"><i class="fa fa-check-circle text-primary me-1"></i> Votre confort,
                                        notre priorité.</p>
                                    <p class="mb-2"><i class="fa fa-check-circle text-primary me-1"></i> Louez, vivez,
                                        voyagez !</p>
                                    <p class="mb-2"><i class="fa fa-check-circle text-primary me-1"></i> Planifiez,
                                        plongez,
                                        et explorez</p>
                                    <p class="mb-0"><i class="fa fa-check-circle text-primary me-1"></i> Découvrez de
                                        nouveaux horizons</p>
                                </div>
                            </div>
                            <!-- <div class="col-lg-5 d-flex align-items-center">
                                <a href="about.php" class="btn btn-primary rounded py-3 px-5">Lire plus</a>
                            </div> -->
                            <!-- <div class="col-lg-7">
                                <div class="d-flex align-items-center">
                                    <img src="img/attachment-img.jpg"
                                        class="img-fluid rounded-circle border border-4 border-secondary"
                                        style="width: 100px; height: 100px;" alt="Image">
                                    <div class="ms-4">
                                        <h4>M. ETEKPO Paterne</h4>
                                        <p class="mb-0">Fondateur Oreofe Challenges </p>
                                    </div>
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 wow fadeInRight" data-wow-delay="0.2s">
                    <div class="about-img">
                        <div class="img-1">
                            <img src="img/about-img.jpg" class="img-fluid rounded h-100 w-100" alt="">
                        </div>
                        <div class="img-2">
                            <img src="img/aimage.JPG" class="img-fluid rounded w-100" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- About End -->

    <!-- Fact Counter -->
    <div class="container-fluid counter bg-secondary py-5">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="counter-item text-center">
                        <div class="counter-item-icon mx-auto">
                            <i class="fas fa-thumbs-up fa-2x"></i>
                        </div>
                        <div class="counter-counting my-3">
                            <span class="text-white fs-2 fw-bold" data-toggle="counter-up">224</span>
                            <span class="h1 fw-bold text-white">+</span>
                        </div>
                        <h4 class="text-white mb-0">Clients Satisfaits</h4>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="counter-item text-center">
                        <div class="counter-item-icon mx-auto">
                            <i class="fas fa-car-alt fa-2x"></i>
                        </div>
                        <div class="counter-counting my-3">
                            <span class="text-white fs-2 fw-bold" data-toggle="counter-up">32</span>
                            <span class="h1 fw-bold text-white">+</span>
                        </div>
                        <h4 class="text-white mb-0">Nombre de Véhicules</h4>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="counter-item text-center">
                        <div class="counter-item-icon mx-auto">
                            <i class="fas fa-building fa-2x"></i>
                        </div>
                        <div class="counter-counting my-3">
                            <span class="text-white fs-2 fw-bold" data-toggle="counter-up">3</span>
                            <span class="h1 fw-bold text-white">+</span>
                        </div>
                        <h4 class="text-white mb-0">Nos Parcs</h4>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.7s">
                    <div class="counter-item text-center">
                        <div class="counter-item-icon mx-auto">
                            <i class="fas fa-clock fa-2x"></i>
                        </div>
                        <div class="counter-counting my-3">
                            <span class="text-white fs-2 fw-bold" data-toggle="counter-up">17584</span>
                            <span class="h1 fw-bold text-white">+</span>
                        </div>
                        <h4 class="text-white mb-0">Kilomètres parcourus</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Fact Counter -->

    <!-- Features Start -->
    <!-- <div class="container-fluid feature py-5">
        <div class="container py-5">
            <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 800px;">
                <h1 class="display-5 text-capitalize mb-3">Nos <span class="text-primary">Services</span></h1>
                <p class="mb-0">Nous nous engageons à vous offrir un service de qualité, un suivi personnalisé et
                    un accompagnement sur mesure.
                </p>
            </div>
            <div class="row g-4 align-items-center">
                <div class="col-xl-4">
                    <div class="row gy-4 gx-0">
                        <div class="col-12 wow fadeInUp" data-wow-delay="0.1s">
                            <div class="feature-item">
                                <div class="feature-icon">
                                    <span class="fa fa-trophy fa-2x"></span>
                                </div>
                                <div class="ms-4">
                                    <h5 class="mb-3"> LOCATION DE VOITURES </h5>
                                    <p class="mb-0"> Une large sélection de véhicules pour tous les types de
                                        déplacements.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 wow fadeInUp" data-wow-delay="0.3s">
                            <div class="feature-item">
                                <div class="feature-icon">
                                    <span class="fa fa-road fa-2x"></span>
                                </div>
                                <div class="ms-4">
                                    <h5 class="mb-3"> LOCATION D’APPARTEMENTS </h5>
                                    <p class="mb-0">Profitez des <b>logements confortables</b> et bien situés pour vos
                                        <b>séjours</b> de courte ou longue durée.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 col-xl-4 wow fadeInUp" data-wow-delay="0.2s">
                    <img src="img/features-img.png" class="img-fluid w-100" style="object-fit: cover;" alt="Img">
                </div>
                <div class="col-xl-4">
                    <div class="row gy-4 gx-0">
                        <div class="col-12 wow fadeInUp" data-wow-delay="0.1s">
                            <div class="feature-item justify-content-end">
                                <div class="text-end me-4">
                                    <h5 class="mb-3"> VENTE ET IMPORTATION DE VEHICULES </h5>
                                    <p class="mb-0">Des <b>voitures neuves et d’occasion</b> de qualité, importées selon
                                        vos préférences.</p>
                                </div>
                                <div class="feature-icon">
                                    <span class="fa fa-tag fa-2x"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 wow fadeInUp" data-wow-delay="0.3s">
                            <div class="feature-item justify-content-end">
                                <div class="text-end me-4">
                                    <h5 class="mb-3"> VENTE DE PIECES DETACHEES </h5>
                                    <p class="mb-0"> Des <b>pièces de rechange</b> pour assurer la longévité et la
                                        performance de vos <b>véhicules</b>.</p>
                                </div>
                                <div class="feature-icon">
                                    <span class="fa fa-map-pin fa-2x"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Features End -->


    <!-- Services Start -->
    <div class="container-fluid service py-5">
        <div class="container py-5">
            <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 800px;">
                <h1 class="display-5 text-capitalize mb-3">Nos <span class="text-primary">Services</span>
                </h1>
                <p class="mb-0"> OREOFE CHALLENGES propose une gamme complète de services pour répondre à
                    tous vos
                    besoins : </p>
                </p>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-lg-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item p-4">
                        <div class="service-icon mb-4">
                            <i class="fa fa-phone-alt fa-2x"></i>
                        </div>
                        <h5 class="mb-3"> LOCATION DE VOITURES </h5>
                        <p class="mb-0"> Chez OREOFE CHALLENGES, nous offrons un service de location de
                            voitures de
                            premier ordre, conçu pour répondre à tous vos besoins de mobilité.
                            Notre flotte comprend une large gamme de véhicules, allant des voitures
                            économiques aux
                            modèles de luxe,
                            en passant par les SUV et les minivans.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="service-item p-4">
                        <div class="service-icon mb-4">
                            <i class="fa fa-money-bill-alt fa-2x"></i>
                        </div>
                        <h5 class="mb-3"> RESERVATION EN LIGNE</h5>
                        <p class="mb-0"><b>Réservez votre voiture en toute simplicité.</b> GracE à notre
                            service de
                            réservation en ligne, vous pouvez choisir votre véhicule, sélectionner vos dates
                            de location
                            et ajouter des options supplémentaires en quelques clics. </p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="service-item p-4">
                        <div class="service-icon mb-4">
                            <i class="fa fa-road fa-2x"></i>
                        </div>
                        <h5 class="mb-3"> LOCATION D’APPARTEMENTS </h5>
                        <p class="mb-0">Nos logements sont entièrement équipés et meublés, offrant toutes
                            les commodités
                            nécessaires pour un séjour agréable. De plus, nous proposons une gamme variée
                            d’appartements, allant des studios aux spacieux appartements familiaux, situés
                            dans des
                            quartiers prisés et bien desservis de Cotonou et Calavi. </p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item p-4">
                        <div class="service-icon mb-4">
                            <i class="fa fa-umbrella fa-2x"></i>
                        </div>
                        <h5 class="mb-3"> VENTE ET IMPORTATION DE VEHICULES </h5>
                        <p class="mb-0">Nous nous occupons de
                            toutes les
                            démarches administratives et logistiques pour vous garantir une expérience
                            d’achat sans
                            tracas. Chaque véhicule est rigoureusement inspecté et certifié pour assurer sa
                            fiabilité et
                            sa performance. Que vous cherchiez une voiture pour un usage
                            personnel ou professionnel, notre équipe d’experts est là pour vous conseiller
                            et vous
                            accompagner tout au long du processus.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="service-item p-4">
                        <div class="service-icon mb-4">
                            <i class="fa fa-building fa-2x"></i>
                        </div>
                        <h5 class="mb-3"> VENTE DE PIECES DETACHEES </h5>
                        <p class="mb-0">Nous comprenons l’importance de maintenir votre véhicule en parfait
                            état de
                            fonctionnement, c’est pourquoi nous offrons une large gamme de pièces détachées,
                            allant des
                            composants
                            moteurs aux accessoires de carrosserie. Chaque pièce est soigneusement
                            sélectionnée pour
                            garantir sa fiabilité et sa durabilité.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="service-item p-4">
                        <div class="service-icon mb-4">
                            <i class="fa fa-car-alt fa-2x"></i>
                        </div>
                        <h5 class="mb-3"> TRANSITS ET CONSIGNATION </h5>
                        <p class="mb-0">OREOFE CHALLENGES offre des services de transit et de consignation
                            pour répondre
                            à tous vos besoins logistiques. Nous comprenons l’importance de la rapidité et
                            de la
                            fiabilité
                            dans le transport de marchandises, c’est pourquoi nous nous engageons à fournir
                            des
                            solutions efficaces et personnalisées.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Services End -->

    <!-- Blog Start -->
    <!-- <div class="container-fluid blog py-5">
        <div class="container py-5">
            <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 800px;">
                <h1 class="display-5 text-capitalize mb-3">Cental<span class="text-primary"> Blog & News</span></h1>
                <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut amet nemo expedita
                    asperiores commodi accusantium at cum harum, excepturi, quia tempora cupiditate! Adipisci facilis
                    modi quisquam quia distinctio,
                </p>
            </div>
            <div class="row g-4">
                <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="blog-item">
                        <div class="blog-img">
                            <img src="img/blog-1.jpg" class="img-fluid rounded-top w-100" alt="Image">
                        </div>
                        <div class="blog-content rounded-bottom p-4">
                            <div class="blog-date">30 Dec 2025</div>
                            <div class="blog-comment my-3">
                                <div class="small"><span class="fa fa-user text-primary"></span><span
                                        class="ms-2">Martin.C</span></div>
                                <div class="small"><span class="fa fa-comment-alt text-primary"></span><span
                                        class="ms-2">6 Comments</span></div>
                            </div>
                            <a href="#" class="h4 d-block mb-3">Rental Cars how to check driving fines?</a>
                            <p class="mb-3">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Eius libero soluta
                                impedit eligendi? Quibusdam, laudantium.</p>
                            <a href="#" class="">Read More <i class="fa fa-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="blog-item">
                        <div class="blog-img">
                            <img src="img/blog-2.jpg" class="img-fluid rounded-top w-100" alt="Image">
                        </div>
                        <div class="blog-content rounded-bottom p-4">
                            <div class="blog-date">25 Dec 2025</div>
                            <div class="blog-comment my-3">
                                <div class="small"><span class="fa fa-user text-primary"></span><span
                                        class="ms-2">Martin.C</span></div>
                                <div class="small"><span class="fa fa-comment-alt text-primary"></span><span
                                        class="ms-2">6 Comments</span></div>
                            </div>
                            <a href="#" class="h4 d-block mb-3">Rental cost of sport and other cars</a>
                            <p class="mb-3">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Eius libero soluta
                                impedit eligendi? Quibusdam, laudantium.</p>
                            <a href="#" class="">Read More <i class="fa fa-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="blog-item">
                        <div class="blog-img">
                            <img src="img/blog-3.jpg" class="img-fluid rounded-top w-100" alt="Image">
                        </div>
                        <div class="blog-content rounded-bottom p-4">
                            <div class="blog-date">27 Dec 2025</div>
                            <div class="blog-comment my-3">
                                <div class="small"><span class="fa fa-user text-primary"></span><span
                                        class="ms-2">Martin.C</span></div>
                                <div class="small"><span class="fa fa-comment-alt text-primary"></span><span
                                        class="ms-2">6 Comments</span></div>
                            </div>
                            <a href="#" class="h4 d-block mb-3">Document required for car rental</a>
                            <p class="mb-3">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Eius libero soluta
                                impedit eligendi? Quibusdam, laudantium.</p>
                            <a href="#" class="">Read More <i class="fa fa-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Blog End -->

    <!-- Team Start 
    <div class="container-fluid team py-5">
        <div class="container py-5">
            <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 800px;">
                <h1 class="display-5 text-capitalize mb-3">Customer<span class="text-primary"> Suport</span> Center</h1>
                <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut amet nemo expedita
                    asperiores commodi accusantium at cum harum, excepturi, quia tempora cupiditate! Adipisci facilis
                    modi quisquam quia distinctio,
                </p>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item p-4 pt-0">
                        <div class="team-img">
                            <img src="img/team-1.jpg" class="img-fluid rounded w-100" alt="Image">
                        </div>
                        <div class="team-content pt-4">
                            <h4>MARTIN DOE</h4>
                            <p>Profession</p>
                            <div class="team-icon d-flex justify-content-center">
                                <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i
                                        class="fab fa-twitter"></i></a>
                                <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i
                                        class="fab fa-instagram"></i></a>
                                <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i
                                        class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="team-item p-4 pt-0">
                        <div class="team-img">
                            <img src="img/team-2.jpg" class="img-fluid rounded w-100" alt="Image">
                        </div>
                        <div class="team-content pt-4">
                            <h4>MARTIN DOE</h4>
                            <p>Profession</p>
                            <div class="team-icon d-flex justify-content-center">
                                <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i
                                        class="fab fa-twitter"></i></a>
                                <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i
                                        class="fab fa-instagram"></i></a>
                                <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i
                                        class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="team-item p-4 pt-0">
                        <div class="team-img">
                            <img src="img/team-3.jpg" class="img-fluid rounded w-100" alt="Image">
                        </div>
                        <div class="team-content pt-4">
                            <h4>MARTIN DOE</h4>
                            <p>Profession</p>
                            <div class="team-icon d-flex justify-content-center">
                                <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i
                                        class="fab fa-twitter"></i></a>
                                <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i
                                        class="fab fa-instagram"></i></a>
                                <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i
                                        class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.7s">
                    <div class="team-item p-4 pt-0">
                        <div class="team-img">
                            <img src="img/team-4.jpg" class="img-fluid rounded w-100" alt="Image">
                        </div>
                        <div class="team-content pt-4">
                            <h4>MARTIN DOE</h4>
                            <p>Profession</p>
                            <div class="team-icon d-flex justify-content-center">
                                <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i
                                        class="fab fa-twitter"></i></a>
                                <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i
                                        class="fab fa-instagram"></i></a>
                                <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i
                                        class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
     Team End -->

    <!-- Banner Start -->
    <div class="container-fluid banner pb-5 wow zoomInDown" data-wow-delay="0.1s">
        <div class="container pb-5">
            <div class="banner-item rounded">
                <img src="img/banner-1.jpg" class="img-fluid rounded w-100" alt="">
                <div class="banner-content">
                    <h2 class="text-primary"> Contactez-nous</h2>
                    <h2 class="text-white">Interressé par nos <b>Véhicules</b> ?</h2>
                    <h5 class="text-white">N'hesitez pas, envoyez - nous un message.</h5>
                    <div class="banner-btn">
                        <a href="https://wa.me/94371616"
                            class="btn btn-secondary rounded-pill py-3 px-4 px-md-5 me-2">WhatsApp</a>
                        <a href="tel:+2290194371616"
                            class="btn btn-primary rounded-pill py-3 px-4 px-md-5 ms-2">Contactez -
                            Nous !</a>
                        <a href="contact.php" class="btn btn-primary rounded-pill py-3 px-4 px-md-5 ms-2">Donnez votre
                            Avis!</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Banner End -->


    <!-- Footer Start -->
    <div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <div class="footer-item">
                            <h4 class="text-white mb-4">A propos</h4>
                            <p class="mb-3">Besoin d’une <b>voiture</b> ou d’un <b>appartement</b> ? Contactez-nous dès
                                maintenant pour réserver ou obtenir plus d’informations</p>
                        </div>
                        <div class="position-relative">
                        <form action="" method="POST" class="sign-up-form d-flex" data-aos="fade-up"
                                data-aos-delay="300">
                                <input class="form-control rounded-pill w-100 py-3 ps-4 pe-5" type="text" name="nom"
                                    id="nom" placeholder="Enter your email">
                                <button type="submit" name="submit" id="submit"
                                    class="btn btn-secondary rounded-pill position-absolute top-0 end-0 py-2 mt-2 me-2">Abonnez
                                    - vous !</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-white mb-4">Liens rapides</h4>
                        <a href="about.php"><i class="fas fa-angle-right me-2"></i> A propos</a>
                        <a href="cars.php"><i class="fas fa-angle-right me-2"></i> Nos voitures</a>
                        <a href="properties.php"><i class="fas fa-angle-right me-2"></i>Nos propriétés</a>
                        <a href="contact.php"><i class="fas fa-angle-right me-2"></i> Contactez - nous !</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-5">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-white mb-4"> Nos Contacts</h4>
                        <a href="#"><i class="fa fa-map-marker-alt me-2"></i> BP 1517, CENSAD Erevan, Cotonou, Bénin</a>
                        <a href="mailto:oreofechallenges@gmail.com"><i class="fas fa-envelope me-2"></i>
                            oreofechallenges@gmail.com</a>
                        <a href="tel:+012 345 67890"><i class="fas fa-phone me-2"></i> +229 01 943 716 16</a>
                        <a href="tel:+012 345 67890" class="mb-3"><i class="fas fa-print me-2"></i> +229 01 974 474
                            77</a>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-xl-1">
                    <div class="footer-item d-flex flex-column">
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                href="https://m.facebook.com/people/Or%25C3%25A9of%25C3%25AA-Challenges/100088868176677"><i
                                    class="fab fa-facebook-f text-white"></i></a>
                        </div>
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                href="https://www.tiktok.com/%40orofchallenges"><i
                                    class="fab fa-tiktok text-white"></i></a>
                        </div>
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-3"
                                href="https://www.instagram.com/oreofe_challenges/"><i
                                    class="fab fa-instagram text-white"></i></a>
                        </div>
                        <div class="mb-3">
                            <a class="btn btn-secondary btn-md-square rounded-circle me-0"
                                href="https://bj.linkedin.com/company/oreofe-challenges"><i
                                    class="fab fa-linkedin-in text-white"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->

    <!-- Copyright Start -->
    <div class="container-fluid copyright py-4">
        <div class="container">
            <div class="row g-4 align-items-center">
                <div class="col-md-8 text-center text-md-start mb-md-0">
                    <span class="text-body"><a href="#" class="border-bottom text-white"><i
                                class="fas fa-copyright text-light me-2"></i>OREOFE CHALLENGES LOCATION DE VOITURES ET
                            HEBERGEMENTS</a>, All right reservés.</span>
                </div>
                <div class="col-md-4 text-center text-md-end text-body">
                    <!--/*** This template is free as long as you keep the below author’s credit link/attribution link/backlink. ***/-->
                    <!--/*** If you'd like to use the template without the below author’s credit link/attribution link/backlink, ***/-->
                    <!--/*** you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". ***/-->
                    Designed By <a class="border-bottom text-white" href="mailto:digitalnative3@gmail.com"> Digital
                        Native</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Copyright End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-secondary btn-lg-square rounded-circle back-to-top"><i class="fa fa-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>


    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>